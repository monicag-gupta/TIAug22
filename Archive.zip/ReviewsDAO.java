import java.sql.Connection;
import java.sql.Statement;

public class ReviewsDAO {

	public ReviewsDAO() {
	}

	public int addReview(Review r, Connection con) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("Insert into Review(movie_id,review,user_id) values(" + r.getMovie_id() + ",'"
					+ r.getReview() + "'," + r.getUser_id() + ")");
		} catch (Exception e) {
			System.out.println(e);
		}
		return s;
	}
}