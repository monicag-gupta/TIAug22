public class Rating {

	private int rating_id;
	private int rating;
	private int movie_id;
	private int user_id;

	public Rating() {
	}

	public Rating(int rating, int movie_id, int user_id) {
		this.rating = rating;
		this.movie_id = movie_id;
		this.user_id = user_id;
	}

	public int getRating_id() {
		return rating_id;
	}

	public void setRating_id(int rating_id) {
		this.rating_id = rating_id;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getMovie_id() {
		return movie_id;
	}

	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String toString() {
		return "Rating [rating_id=" + rating_id + ", rating=" + rating + ", movie_id=" + movie_id + ", user_id="
				+ user_id + "]";
	}

}