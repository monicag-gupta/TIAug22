import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws SQLException {

		Scanner sc = new Scanner(System.in);

		MoviesDAO movieD = new MoviesDAO();
		UsersDAO userD = new UsersDAO();
		ReviewsDAO reviewD = new ReviewsDAO();
		RatingsDAO ratingD = new RatingsDAO();

		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalprj", "root", "aditya@123");
		} catch (Exception e) {
			System.out.println(e);
		}

		while (true) {
			System.out.println("Please enter your choice: ");
			System.out.println(
					"1. Add a new movie entry \n2. Edit an existing movie entry \n3. Add a review to a movie \n4. Rate a movie \n5. View a list of movies from a genre \n6. View a list of top 10 movies overall \n7. View a list of top 10 movies from a genre \n8. Search for a movie by name \n9. Search for a movie by name and genre \n10. View details of a movie \n11. Exit");

			int ch = sc.nextInt();
			sc.nextLine();

			if (ch >= 1 && ch <= 4) {

				System.out.println("Please enter your username");
				String u = sc.nextLine();

				if (!userD.isUser(u, con)) {

					System.out.println("You must be a registered user to add/edit");

				} else {

					int uid = userD.Users_id(u, con);

					if (ch == 1) {
						System.out.println("Please enter movie ID");
						int movie_id = sc.nextInt();
						sc.nextLine();
						System.out.println("Please enter the movie name");
						String name = sc.nextLine();
						System.out.println("Please enter the summary");
						String summary = sc.nextLine();
						System.out.println("Please enter the cast");
						String cast = sc.nextLine();
						System.out.println("Please enter the genre");
						String genre = sc.nextLine();
						movieD.save(new Movie(movie_id, name, summary, cast, genre, 0.0F, uid), con);
					} else if (ch == 2) {
						System.out.println("Please enter movie ID");
						int movie_id = sc.nextInt();
						sc.nextLine();
						System.out.println("Please enter the updated movie name");
						String name = sc.nextLine();
						System.out.println("Please enter the updated summary");
						String summary = sc.nextLine();
						System.out.println("Please enter the updated cast");
						String cast = sc.nextLine();
						System.out.println("Please enter the updated genre");
						String genre = sc.nextLine();
						movieD.update(new Movie(movie_id, name, summary, cast, genre), con);
					} else if (ch == 3) {
						System.out.println("Please enter movie ID");
						int movie_id = sc.nextInt();
						sc.nextLine();
						System.out.println("Please enter the review");
						String review = sc.nextLine();
						reviewD.addReview(new Review(review, movie_id, uid), con);
					} else if (ch == 4) {
						System.out.println("Please enter movie ID");
						int movie_id = sc.nextInt();
						sc.nextLine();
						System.out.println("Please give the rating");
						int rating = sc.nextInt();
						ratingD.addRating(new Rating(rating, movie_id, uid), con);
						ratingD.updateRating(movie_id, con);

					}
				}
			} else if (ch == 5) {
				System.out.println("Please enter genre");
				String g = sc.nextLine();
				List<Movie> movies = movieD.listMoviesByGenre(g, con);
				System.out.println(movies);
			} else if (ch == 6) {
				List<String> movies = movieD.topTenOverall(con);
				System.out.println(movies);
			} else if (ch == 7) {
				System.out.println("Please enter genre");
				String g = sc.nextLine();
				List<String> movies = movieD.topTenByGenre(g, con);
				System.out.println(movies);
			} else if (ch == 8) {
				System.out.println("Please enter name");
				String n = sc.nextLine();
				List<Movie> r = movieD.listMoviesByName(n, con);
				System.out.println(r);
			} else if (ch == 9) {
				System.out.println("Please enter name");
				String n = sc.nextLine();
				System.out.println("Please enter genre");
				String g = sc.nextLine();
				List<Movie> r = movieD.listMoviesByNameAndGenre(n, g, con);
				System.out.println(r);
			} else if (ch == 10) {
				System.out.println("Please enter name");
				String n = sc.nextLine();
				System.out.println(movieD.movieDetails(n, con));
			} else if (ch == 11) {
				con.close();
				break;
			} else {
				System.out.println("Invalid Input");
			}

		}

	}

}