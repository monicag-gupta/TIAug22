public class Movie {

	private int movie_id;
	private String movie_name;
	private String summary;
	private String cast;
	private String genre;
	private float average_rating;
	private int user_id;

	public Movie() {
	}

	public Movie(int id, String movie_name, String summary, String cast, String genre, float average_rating,
			int user_id) {
		this.movie_id = id;
		this.movie_name = movie_name;
		this.summary = summary;
		this.cast = cast;
		this.genre = genre;
		this.average_rating = average_rating;
		this.user_id = user_id;
	}

	public Movie(int id, String movie_name, String summary, String cast, String genre) {
		this.movie_name = movie_name;
		this.summary = summary;
		this.cast = cast;
		this.genre = genre;
	}

	public int getMovie_id() {
		return movie_id;
	}

	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}

	public String getMovie_name() {
		return movie_name;
	}

	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public float getAverage_rating() {
		return average_rating;
	}

	public void setAverage_rating(float average_rating) {
		this.average_rating = average_rating;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String toString() {
		return "Movie [id=" + movie_id + ", movie_name=" + movie_name + ", summary=" + summary + ", cast=" + cast
				+ ", genre=" + genre + ", average_rating=" + average_rating + ", user_id=" + user_id + "]";
	}

}