import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MoviesDAO {

	public MoviesDAO() {
	}

	public int save(Movie m, Connection con) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(
					"insert into Movie(movie_name, summary, cast, genre, average_rating, user_id) values('"
							+ m.getMovie_name() + "', '" + m.getSummary() + "','" + m.getCast() + "','" + m.getGenre()
							+ "'," + m.getAverage_rating() + ",'" + m.getUser_id() + "')");
		} catch (Exception e) {
			System.out.println(e);
		}
		return s;
	}

	public int update(Movie m, Connection con) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(
					"update Movie " + "set movie_name='" + m.getMovie_name() + "',summary= '" + m.getSummary() + "',cast='"
							+ m.getCast() + "',genre='" + m.getGenre() + "'" + "where movie_id=" + m.getMovie_id());
		} catch (Exception e) {
			System.out.println(e);
		}
		return s;
	}

	public List<Movie> listMoviesByName(String movie, Connection con) {
		List<Movie> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Movie where movie_name ='" + movie + "'");
			while (rs.next())
				movies.add(new Movie(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7)));
		} catch (Exception e) {
			System.out.println(e);
		}
		return movies;
	}

	public List<Movie> listMoviesByGenre(String genre, Connection con) {
		List<Movie> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Movie where genre ='" + genre + "'");
			while (rs.next())
				movies.add(new Movie(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getFloat(6), rs.getInt(7)));
		} catch (Exception e) {
			System.out.println(e);
		}
		return movies;
	}

	public List<Movie> listMoviesByNameAndGenre(String name, String genre, Connection con) {
		List<Movie> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Movie where movie_name ='" + name + "' and genre ='" + genre + "'");
			while (rs.next())
				movies.add(new Movie(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getFloat(6), rs.getInt(7)));
		} catch (Exception e) {
			System.out.println(e);
		}
		return movies;
	}

	public List<String> topTenOverall(Connection con) {
		List<String> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select movie_name from Movie  order by average_rating desc limit 10");
			while (rs.next()) {
				movies.add(rs.getString(1));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return movies;
	}

	public List<String> topTenByGenre(String genre, Connection con) {
		List<String> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"Select movie_name from Movie where genre='" + genre + "' order by average_rating desc limit 10");
			while (rs.next()) {
				movies.add(rs.getString(1));
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return movies;
	}

	public List<String> movieDetails(String n, Connection con) {
		List<String> res = new ArrayList<>();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"Select Movie.movie_name, Movie.summary, Movie.cast, Movie.genre, Review.review from Movie inner join Review on Movie.movie_id = Review.movie_id where movie_name='"
							+ n + "'");
			String name = null, summary = null, cast = null, genre = null, review = null;
			while (rs.next()) {
				name = rs.getString(1);
				summary = rs.getString(2);
				cast = rs.getString(3);
				genre = rs.getString(4);
				review = rs.getString(5);
			}
			res.add(name);
			res.add(summary);
			res.add(cast);
			res.add(genre);
			res.add(review);
		} catch (Exception e) {
			System.out.println(e);
		}
		return res;
	}
}