import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class UsersDAO {

	public UsersDAO() {
	}

	public boolean isUser(String user, Connection con) {
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select user_id from Users where user_name='" + user + "'");
			if (rs.next())
				return true;
			return false;
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

	public int Users_id(String user_name, Connection con) {
		Statement stmt;
		int uid = 0;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Users where user_name='" + user_name + "'");
			while (rs.next())
				uid = rs.getInt(1);
		} catch (Exception e) {
			System.out.println(e);
		}
		return uid;
	}
}