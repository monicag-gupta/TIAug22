import java.sql.Connection;
import java.sql.Statement;

public class RatingsDAO {

	public RatingsDAO() {
	}

	public int addRating(Rating r, Connection con) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("Insert into Rating(movie_id, rating, user_id) values(" + r.getMovie_id() + ","
					+ r.getRating() + "," + r.getUser_id() + ")");
		} catch (Exception e) {
			System.out.println(e);
		}
		return s;
	}

	public int updateRating(int movie_id, Connection con) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("update Movie set average_rating= (Select sum(rating)/count(rating_id) "
					+ "from Rating where movie_id=" + movie_id + ") where movie_id=" + movie_id);

		} catch (Exception e) {
			System.out.println(e);
		}
		return s;
	}

}