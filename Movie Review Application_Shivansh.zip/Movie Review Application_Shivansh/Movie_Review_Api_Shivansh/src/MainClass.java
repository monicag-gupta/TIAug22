import java.sql.SQLException;
import java.util.*;
import java.io.Console;
import java.io.IOException;


public class MainClass extends Create_User {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args)  
	{
		String port="3306", user="root", name="Shivansh", pass1="password";
		int ch=0;
		char[] pass = null;
		String db_URL = "jdbc:mysql://localhost:", db="movie", url="";

		String q_user = "CREATE TABLE users ("
			            + "User_id INT NOT NULL AUTO_INCREMENT, "
			            + "User_name VARCHAR(64) NOT NULL,"
			            + "Email_id VARCHAR(64) NOT NULL UNIQUE, PRIMARY KEY (User_id))", 
	            
	            q_movie = "Create table movie ("
	            		+ "Movie_id INT Auto_increment NOT NULL, "
	            		+ "Movie_name varchar(100) Not Null,"
	            		+ "Summary varchar(500), "
	            		+ "Genre varchar(200),"
	            		+ "Cast varchar(200),"
	            		+ "Average_rating float,"
	            		+ "User_id int DEFAULT 1,"
	            		+ "FOREIGN KEY (User_id) REFERENCES users(User_id), PRIMARY KEY (Movie_id))",

        		q_review = "CREATE TABLE review ("
	    	            + "Review_id INT NOT NULL AUTO_INCREMENT,"
        				+ "Movie_id INT NOT NULL DEFAULT 1,"
	    	            + "Reviews VARCHAR(500),"
	    	            + "User_id int DEFAULT 1,"
	    	            + "FOREIGN KEY (User_id) REFERENCES users(User_id),"
	    	            + "FOREIGN KEY (Movie_id) REFERENCES movie(Movie_id), PRIMARY KEY (Review_id))",        		
	            		
	            q_rating = "CREATE TABLE rating ("
	    	            + "Rating_id INT NOT NULL AUTO_INCREMENT,"
	            		+ "Movie_id INT NOT NULL  DEFAULT 1,"
	    	            + "Ratings INT, User_id INT DEFAULT 1,"
	            		+ "Email_id VARCHAR(64) NOT NULL UNIQUE DEFAULT '', "
	    	            + "FOREIGN KEY (User_id) REFERENCES users(User_id),"
	    	            + "FOREIGN KEY (Email_id) REFERENCES users(Email_id),"
	    	            + "FOREIGN KEY (Movie_id) REFERENCES movie(Movie_id), PRIMARY KEY (Rating_id))";		
		
		try
		{
			System.out.println("\t\t\t\tWelcome to the App MoviesWorld \nLet's begin! "
					+ "\nWhat's your good name?");
			name=sc.nextLine();
			
			System.out.println("Nice to meet you " + name + "!");
			
			System.out.print("Registering your database...\n");
			System.out.print("\nEnter Port number(3306 by default): ");
			port=sc.nextLine();
			
			System.out.print("\nEnter your database username(root by default): ");
			user=sc.nextLine();			
			
			System.out.print("\nEnter your database password(password by default): ");
			
			Console cons = System.console();
			if ((cons = System.console()) != null)
				pass = cons.readPassword("Enter password"); 
			else
				pass=sc.next().toCharArray();
			db_URL+=port+"/";
			url+=db_URL + db;		//convert to full URL
			pass1 = String.valueOf(pass);		//convert to string	
			
			Check.dbexists(db_URL, user, pass1,db);
			
			System.out.println("Checking tables....");
			Check.create(url, user, pass1,q_user);	
			Check.create(url, user, pass1,q_movie);
			Check.create(url, user, pass1,q_review);	
			Check.create(url, user, pass1,q_rating);	
			System.out.println("Done.");
			System.out.println("Database connection established successfully! \nPress Enter...");
			sc.nextLine();
			
			String em="";
			while (true) {
				System.out
						.println("\nMenu\n1. Use as a guest \n2. Login \n3. Register \n4. Exit");
				System.out.println("Enter your choise :");
				ch = sc.nextInt();
				if (ch == 1) {
					ViewOrEdit obj = new ViewOrEdit();
					obj.choice(url, user, pass1, em, name, 1);
					
				} else if (ch == 2) {
					sc.nextLine();
					System.out.print("\nEnter your registered name: ");
					name=sc.nextLine();
					System.out.println("Enter email id: ");
					em = sc.next();
					System.out.println("\nVerifying...");
					Read_User.check(url, user, pass1, em, name);
					
					char cont='1';
					do{
						System.out.println("Please select one of the following:");
						System.out.println("\n1. View");
						System.out.println("2. Add");
						ch=sc.nextInt();
						if(ch==1 || ch==2){
							ViewOrEdit obj = new ViewOrEdit();
							try {
								obj.choice(url, user, pass1, em, name, ch);
							} 
							catch (SQLException e) {
								e.printStackTrace();
							}
							System.out.println("\nTo continue using? \nPress '1'");
							sc.nextLine();
							cont = sc.next().charAt(0);
							
							if(!(cont == '1'))
							{
								System.out.println("Bye! We Thank You for using our service.");
								System.gc();
							}
						}
						else if(ch==0){
							break;
						}else {
							System.out.println("Wrong Choice, Try again!");
						}
					}while(cont == '1');

				} else if (ch == 3) {
					sc.nextLine();
					System.out.print("\nEnter your name for registration: ");
					name=sc.nextLine();
					System.out.println("Enter email id: ");
					em=sc.next();
					System.out.println("Creating...\n");
					Create_User.users(url,user,pass1,name,em);
					em = Create_User.str;		// if email is modified, str stores the modified email
					System.out.println("Your Login Credentials:\nUsername: "+ name 
							+"\nEmail Id: " + em);
					
				} else if (ch == 4) {
					break;
				}else {
					System.out.println("Bad Choice, Try Again");
				}
			}
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}	
	}
}