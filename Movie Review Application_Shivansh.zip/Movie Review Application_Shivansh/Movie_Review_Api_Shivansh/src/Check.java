import java.sql.*;

public class Check {
	public static void dbexists(String url, String uname, String pass, String db) throws ClassNotFoundException, SQLException
	{
		Connection con = null;
		
		try {
			System.out.println("\nVerifying Database...");			
			 con = DriverManager.getConnection(url, uname, pass);
		    Statement smt = con.createStatement();
		    String sql = "create database if not exists " + db;		    
		    smt.executeUpdate(sql);		    		    
		} 
		catch (SQLException sqlException) {
		    if (sqlException.getErrorCode() == 1007)	// Database already exists error 
		    {		        
		        System.out.println(sqlException.getMessage());
		    } 
		    else {
		        
		        sqlException.printStackTrace();
		        System.exit(0);
		    }
		}
		finally{
			if(con!=null)
				con.close();
		}
		
		System.out.println("Done.\n");
		
	}
	
	public static void create(String url, String uname, String pass, String q1) throws SQLException
	{	
		Connection con1 = null;
		try{						
			con1 = DriverManager.getConnection(url, uname, pass);
			
			con1.createStatement().executeUpdate(q1);
			
		}
		catch (Exception e) {
			System.out.println(e);
			//System.exit(0);
		}
		finally{
			if(con1 != null)
				con1.close();
		}
		
	}
}