package defaultIO;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class fileWriteCopy2Ex {
	public static void main(String[] args) throws IOException {
		//String path = "/Users/Shivam/shivam_rt/Name_Collection.txt";
		File file =  new File("/Users/Shivam/shivam_tr/Name_Collection.txt");
		if(!file.exists()) {
			file.createNewFile();
		}
		FileWriter writer = new FileWriter(file,true);
		System.out.println("Hi, User enter your name.");
		Scanner sc = new Scanner(System.in);
		String nm = sc.next();
		System.out.println("Hello " + nm);
		Date dt  =  new Date();
		String ans = nm + " Login Time " + dt+"\n"; 
		writer.write(ans);
		 writer.flush();
	      writer.close();
	     
	      
		
	}

}
