package defaultIO;

public class test {
	public static void main(String[] args) {
		String s = "shivam";
		System.out.println(s.substring(1, 3));
	}

}
