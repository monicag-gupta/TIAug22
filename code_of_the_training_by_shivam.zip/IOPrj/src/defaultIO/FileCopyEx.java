package defaultIO;
import java.io.*;
public class FileCopyEx {
	public static void main(String[] args) throws FileNotFoundException {
		if(args.length!=1) {
			System.err.println("Error in the arguments.");
		}
		else {
			if(args[0].length()<5) {
				System.err.println("Error in the arguments.");
				
			}
			else {
				String jav = args[0].substring(args[0].length() - 5, args[0].length());
				if(jav.compareTo(".java")!=0) {
					System.err.println("Error in the arguments.");
				}
				else {
					String name  = "";
					int i = args[0].length() - 6;
					
					int j = i;
					while(args[0].charAt(i)!='/') {
						i--;
					}
					String st = args[0].substring(0, i+1);
					i++;
					name = args[0].substring(i, j + 1);
					String ext = ".clas";
					String nm = name;
					name+=ext;
					st+=name;
					try {
						FileInputStream from = new FileInputStream(args[0]);
						FileOutputStream to = new FileOutputStream(st);
						byte[] buffer = new byte[4096];
						int bytes_read;
						while ((bytes_read = from.read(buffer)) != -1)
							to.write(buffer, 0, bytes_read);
						System.out.println("Compiled " +nm + ".java into " + nm + ".clas successfully");
						from.close();
						to.close();
					} catch (Exception e) {
						System.err.println(e.getMessage());
					}
				}
			}
		}
	}
}
