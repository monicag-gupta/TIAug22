package defaultIO;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadWriteAppend {
	   public static void main(String args[])throws IOException {
	      File file = new File("/Users/Shivam/shivam_tr/Hello.txt");
	      // creates the file
	      if(!file.exists()) file.createNewFile();
	      // creates a FileWriter Object
	      FileWriter writer = new FileWriter(file,true); //true tells that we are appending the file
	      // Writes the content to the file
	      writer.write("This\nis\nan\nexample of\nFile Reader and Writer"); 
	      writer.flush();
	      writer.close();
	      // Creates a FileReader Object
	      FileReader fr = new FileReader(file); 
	      char [] a = new char[150];
	      fr.read(a);   // reads the content to the array
	      //System.out.println(new String(a));
	      for(char c : a)
	         System.out.print(c);   // prints the characters one by one
	      fr.close();
	   }
	}
