package defaultIO;
import java.nio.file.*;
// NIO is better than file reader and file writer and that byte stuff
// It is good, that file reader is not to be used..
public class pathFileNIOCreateDir {
//	"/Users/Shivam/shivam_tr/subDir"
	public static void main(String[] args) throws java.io.IOException {
		//Step1:
//				 Path dirPath =Paths.get("/Users/Shivam/shivam_tr/subDir");
//				 if(!Files.exists(dirPath))
//				 Files.createDirectories(dirPath);
//				 System.out.println("Done1");

				//Step 2: 
//				Path sourcePath = Paths.get("/Users/Shivam/shivam_tr/test.txt");
//				 Path destinationPath = Paths.get("/Users/Shivam/shivam_tr/test2.txt");
//				 Files.copy(sourcePath, destinationPath);
//				 System.out.println("Done2");

				//Step3:
//				Path sourcePath = Paths.get("/Users/Shivam/shivam_tr/test.txt");
//				Path destinationPath = Paths.get("/Users/Shivam/shivam_tr/test-copy.txt");
//				Files.copy(sourcePath, destinationPath,
//							StandardCopyOption.REPLACE_EXISTING);
//				System.out.println("Done3");

				
//				Step 4: 
//				Path sourcePath = Paths.get("/Users/Shivam/shivam_tr/test.txt");
//				Path destinationPath = Paths.get("/Users/Shivam/shivam_tr/testNew.txt");		
//				Files.move(sourcePath, destinationPath,
//				            StandardCopyOption.REPLACE_EXISTING);
//				System.out.println("Done4");
		
		
				

	}
}

