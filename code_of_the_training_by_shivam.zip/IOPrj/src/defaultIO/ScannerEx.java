package defaultIO;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ScannerEx {
	public static void main(String[] args) throws FileNotFoundException {
		//File text = new File("/Users/Shivam/shivam_tr/test.txt");
		File test = new File("/Users/Shivam/shivam_tr/test.txt");
		Scanner sc =  new Scanner(test);
		int lineNumber = 1;
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			System.out.println("line " + (lineNumber++) + " :" + line);
		}
		
	}

}
