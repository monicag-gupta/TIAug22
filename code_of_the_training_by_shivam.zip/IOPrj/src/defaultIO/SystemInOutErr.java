package defaultIO;
import java.io.*;
public class SystemInOutErr {

	public static void main(String[] args) {
		// bufferedReader is outdated..
		//  nowadays scanner is used mostly..
		try(InputStreamReader isr = new InputStreamReader(System.in);
		   BufferedReader br = new BufferedReader(isr)){
		   System.out.println("Enter Your Employer Name:");
		   String name = br.readLine();
		   System.out.println("Enter Your Basic Salary:");
		   String salary1 = br.readLine();
		   int salary2 = Integer.parseInt(salary1);
		   System.out.println("Enter Your House Rent:");
		   String rent1 = br.readLine();
		   double rent2 = Double.parseDouble(rent1);
		   System.out.println("Your name is " + name);
		   System.out.println("Your Total Salary is " + (salary2+rent2));
		}
		catch(Exception e){
			System.out.println(e);
		}
		System.err.println("This is to bring to notice or display error messages");
//		We can create a Scanner object by invoking several different constructors.
//		Scanner(File source)           Constructs a new Scanner that produces values scanned from the specified file.
//		Scanner(InputStream source)           Constructs a new Scanner that produces values scanned from the specified input stream.
//		Scanner(Readable source)           Constructs a new Scanner that produces values scanned from the specified source.
//		Scanner(String source)           Constructs a new Scanner that produces values scanned from the specified string.

		
		
		

	}

}