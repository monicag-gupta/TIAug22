package defaultIO;
class extraException extends Exception{
	public extraException(){
		super("Length of the input is not allowed.");
	}
	public extraException(String s) {
		super(s);
	}
}
public class commandlineArgsEx {
	public static void main(String[] args) {
//		to throw exception outside the try block 
//		you have to extend RuntimeException above instead of Exception
		
//		if(args.length>2||args.length<2) {
//			throw new extraException();
//		}
		try {
			if(args.length>2||args.length<2) {
				throw new extraException();
			}
			int sm = 0;
			for(String s: args) {
				sm+=Integer.parseInt(s);
			}
			System.out.println(sm);
		}
		catch(extraException e) {
			System.out.println(e);
		}
		
	}
}
