package CRUD;
import java.sql.*;
import java.util.Scanner;

public class crudEx {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb", "root", "password");
//here javadb is database name, root is username and password  
		Statement stmt = con.createStatement();
	
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("Hello User, press 1 to enter a new record, 2 to view all the entries, 3 to update a record, 4 to delete any record, -1 to exit");
			int choice = 0;
			choice = sc.nextInt();
			if(choice== -1) {
				con.close();
				break;
			}
			if(choice==1) {
				try {
					System.out.println("Enter id, name, age");
					int id = sc.nextInt();
					String nm = sc.next();
					String age = sc.next();
					String name = "'"+ nm+"'";
					String query = "insert into emp values("+ id + ", "+name+ " ,"+age+")";
					int s = stmt.executeUpdate(query);
					System.out.println(s + " Records inserted");

				}
				catch(Exception e) {
					System.out.println(e);
				}
			}
			else if(choice==2) {
				try {
					ResultSet rs = stmt.executeQuery("select * from emp");
					while (rs.next())
						System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getInt(3));
				}
				catch (Exception e) {
					System.out.println(e);
				}
				
			}
			else if(choice == 3) {
				System.out.println("Enter id to update.");
				int id = sc.nextInt();
				System.out.println("enter new name and age");
				String nm;
				int age;
				nm = sc.next();
				age = sc.nextInt();
				String name = "'"+ nm+"'";
				String query = "update emp set age = " + age + ", name =  "+ name + " where id = " + id;
				try {
					int s = stmt.executeUpdate(query);
					System.out.println(s + " Records updated");
				}
				catch(Exception e){
					System.out.println(e);
				}	
			}
			else if(choice==4) {
				System.out.println("enter id to delete the record. ");
				int id = sc.nextInt();
				String query = "delete from emp where id = " + id;
				try {
					int s = stmt.executeUpdate(query);
					System.out.println(s + " Records deleted");
				}
				catch(Exception e) {
					System.out.println(e);
				}
			}
			else {
				System.out.println("Wrong choice.");
			}
			
		}
	}

}
