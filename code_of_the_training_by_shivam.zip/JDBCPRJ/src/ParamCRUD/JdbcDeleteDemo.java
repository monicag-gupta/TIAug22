package ParamCRUD;

import java.sql.*;

public class JdbcDeleteDemo {
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/javadb";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(dbURL, "root",
					"password");
			String sql = "DELETE FROM Users WHERE username=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, "bill");
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
				System.out.println("A user was deleted successfully!");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}