package ORM;
import java.sql.*;
import java.util.*;

public class EmpDAO {
	Connection con;
	public EmpDAO(){
		con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/javadb", "root", "password");
			// here javadb is database name, root is username and password
		}
		catch(Exception e)
		{}
	}
	public EmpDAO(String driver, String URL, String user, String pass){
		con=null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(
					URL, user, pass);
			// here javadb is database name, root is username and password
		}
		catch(Exception e)
		{}
	}
	public int save(Emp e)
	{
		Statement stmt;
		int s=0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate
					("insert into emp values("+e.getId() + ",'"+e.getName() + "', "+e.getAge() + ")");
		} catch (SQLException e1) {
		}
		return s;
	}
	public int update(Emp e)
	{
		Statement stmt;
		int s=0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate
					("Update emp set age ="+e.getAge() + ", name = '"+e.getName() + "' where id="+e.getId());
		} catch (SQLException e1) {
		}
		return s;
	}
	public int delete(Emp e)
	{
		Statement stmt;
		int s=0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate
					("delete from emp where id="+e.getId());
		} catch (SQLException e1) {
		}
		return s;
	}
	public List<Emp> listEmp(){
		List<Emp> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from emp");
			while (rs.next())
				emps.add(new Emp(rs.getInt(1),rs.getString(2),rs.getInt(3)));
		} catch (Exception e) {}
		
		return emps;
	}
	public void finalise(){
		try {
			con.close();
		} catch (SQLException e) {}
	}
	

}
