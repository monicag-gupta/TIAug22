package ORM;

public class Main {
    // use for non parameterized constructor..
	public static void main(String[] args) {
			EmpDAO edao=new EmpDAO();
			Emp e=new Emp(105,"Hermoine",22);
			System.out.println(edao.save(e)+" records inserted");
			java.util.List<Emp> emps=edao.listEmp();
			System.out.println(emps);

	}
	
	// use for paramterized constructor...
//	public static void main(String[] args) {
//		EmpDAO edao=new EmpDAO("com.mysql.jdbc.Driver","jdbc:mysql://localhost:3306/javadb", "root", "password");
//		Emp e=new Emp(104,"Harry Potter",24);
//		System.out.println(edao.save(e)+" records inserted");
//		
//		java.util.List<Emp> emps=edao.listEmp();
//		System.out.println(emps);
//		e.setAge(26);
//		System.out.println(edao.update(e)+" records updated");
//		emps=edao.listEmp();
//		System.out.println(emps);
//
//}

}
