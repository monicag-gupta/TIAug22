package javaSerialization;
import java.io.*;
class Employee implements java.io.Serializable
{
    public int empID;
    public String empName;
  
    // Default constructor
    public Employee(int empid, String name)
    {
        this.empID = empid;
        this.empName = name;
    }
  
}

public class javaSerializationCls {
	public static void main(String[] args) {
		Employee object = new Employee(1500, "Shivam Bhardwaj");
        String filename = "/Users/Shivam/shivam_tr/serDeser.txt";
          
        // Serialization 
        try
        {   
            //Saving of object in a file
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
              
            // Method for serialization of object
            out.writeObject(object);
              
            out.close();
            file.close();
              
            System.out.println("Object has been serialized");
  
        }
          
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
  
  
        
  
        // Deserialization
        try
        {   
            // Reading the object from a file
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);
              
            // Method for deserialization of object
            Employee object1 = (Employee)in.readObject();
              
            in.close();
            file.close();
              
            System.out.println("Object has been deserialized ");
            System.out.println("The id of the employee after deserialization is  " + object1.empID);
            System.out.println("The name of employee after deserialization is  = " + object1.empName);
        }
          
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
          
        catch(ClassNotFoundException ex)
        {
            System.out.println("ClassNotFoundException is caught");
        }
  
    }
	}
