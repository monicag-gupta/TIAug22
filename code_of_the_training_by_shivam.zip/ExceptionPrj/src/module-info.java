module ExceptionPrj {
	requires java.sql;
}