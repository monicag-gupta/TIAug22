package firstExEg;
import java.util.*;

class emm{
	public int age;
	public String name;
	emm(String nm, int age){
		this.age = age;
		this.name = nm;
	}
	
}

class childException extends RuntimeException{
	public childException(){
		super("Children are not allowed as Employees");
	}
}

class ghostException extends RuntimeException{
	public ghostException(){
		super("Ghosts are not allowed as Employees");
	}
}
class seniorException extends RuntimeException{
	public seniorException(){
		super("Seniors are not allowed as Employees");
	}
}
class purvajException extends RuntimeException{
	public purvajException(){
		super("Purvaj are not allowed as Employees");
	}
}
class duplicateException extends RuntimeException{
	public duplicateException(){
		super("Duplicate names are not allowed as Employees");
	}
}




public class customExceptionEx {
	public static void main(String[] args) {
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		List<emm> lst = new ArrayList<emm>();
		while(true) {
			System.out.println("Enter your choice for the following operations.");
			System.out.println("1. Add");
			System.out.println("2. Display");
			System.out.println("3. Exit");
			choice = sc.nextInt();
			if(choice==1) {
			 System.out.println("Enter name.");
			 // here the error is when we input a line after integer input 
			 // the nextInt() doesn't input the newline character 
			 // the string is empty because it inputs the new line character 
			 // the same error which we used to get in c++ 
			 // so the solution is before we input the string just run it once 
			 // so the new line is ignored before we input the actual line..
			 sc.nextLine();
			 String nm = sc.nextLine();
			 int ag=0;
			 int flg = 0;
			 for(emm sm: lst) {
				 if(sm.name.compareToIgnoreCase(nm)==0) {
					 flg = 1;
					 throw new duplicateException();
				 }
			 }
			 if(flg==0) {
				 System.out.println("Enter age.");
				  ag = sc.nextInt();
				 if(ag<18&&ag>=0) {
					 throw new childException();
				 }
				 else if(ag<0) {
					 throw new ghostException();
				 }
				 else if(ag>60&&ag<=100) {
					 throw new seniorException();
				 }
				 else if(ag>100) {
					 throw new purvajException();
				 }
			 }
			 if(flg==0) {
				 lst.add(new emm(nm ,ag));
			 }
			}
			else if(choice==2) {
				for(emm sm: lst) {
					System.out.println("Name: "+sm.name+" "+"Age: "+sm.age);
				}
			}
			else if(choice==3) {
				break;
			}
			else {
				System.out.println("Bad Choice");
			}
		}
	}

}