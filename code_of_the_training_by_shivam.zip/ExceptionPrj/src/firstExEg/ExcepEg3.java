package firstExEg;
public class ExcepEg3 {
	static int fn(int res){
		System.out.println("Inside function : res: "+res);
		try{
			int a=10/2;
			//a=Integer.parseInt("23a");
			System.out.println("In try, a= " + a + " ; res = " + res);
			return res;
			
		}
		catch(ArithmeticException e){
			System.out.println(e);
			return res=90;
			
		}
		finally{
				res=0;
				System.out.println("\nIn finally : resource Should be 0 but is: "+ res);
		}
		//res=0;
		//return res;
	}

	public static void main(String[] args) {
		int res=0;
		res=10; 
//		try{
//			int z=10/2;  //Case 1: No Exception happened
//			//int z=10/0; //Case 2: Exception is handled
//			//int z=Integer.parseInt("23a"); //case 3: exception is not handled 
////			res = 0;
//		}
//		catch(ArithmeticException e){
//			System.out.println(e);
////			res = 0;
//		}
//		finally{
//			res=0;
//			System.out.println("\nIn finally : resource Should be 0 but is: "+ res);
//		}
		
		res=fn(res);
		System.out.println("resource Should be 0 but is: "+ res);

	}

}