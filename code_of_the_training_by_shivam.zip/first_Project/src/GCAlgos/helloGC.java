package GCAlgos;

public class helloGC {
	public void finalize(){
		helloGC h=new helloGC();
	}
	public helloGC(){
		System.out.println("HelloGC constructed!");
	}
	//slow 
//	-XX:+UseSerialGC
	//fast
//	-XX:+UseG1GC

	public static void main(String[] args) {
//		System.out.println("Hello World!");
		for(;;){
			helloGC h=new helloGC();
		}
		

	}

}