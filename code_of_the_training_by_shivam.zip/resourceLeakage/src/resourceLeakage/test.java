package resourceLeakage;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer current  = new StringBuffer();
		current.append("shivam");
		current.append("shivam");
		current.append("shivam");
		current.append("shivam");
		current.append("shivam");
		System.out.println(current);
		int tt = ' ' -  'a';
		System.out.println(tt);
		
//		 - - - - - - - -
//		 012345678

	}

}
