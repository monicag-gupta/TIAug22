package resourceLeakage;
import java.util.*;
class Res implements AutoCloseable{
	public void usingRes(){
		System.out.println("Here we are using the resource");
	}
	public void close(){
		System.out.println("The Res is closed");
	}
}

public class ResEg2 {

	public static void main(String[] args) {
		
		
		try (Scanner sc = new Scanner(System.in);Res r=new Res()) { // Resource leak: 'sc' is
			r.usingRes();									// never closed
			System.out.println("Enter an Integer:");
			int s = sc.nextInt();
			System.out.println(" Welcome to Java " + s + " times!!");
		}
		
		catch(java.util.InputMismatchException e){
			System.out.println(e);
		}
		finally{
			System.out.println("This is finally block");
		}
		// sc.close();
	}
}

//A resource is an object in a program that must be closed after the program has finished.
//Any object that implements java.lang.AutoCloseable or java.io.Closeable can be passed as a parameter to try statement.
//All the resources declared in the try-with-resources statement will be closed automatically when the try block exits. There is no need to close it explicitly.
//We can write more than one resources in the try statement.
//In a try-with-resources statement, any catch or finally block is run after the resources declared have been closed.
//

