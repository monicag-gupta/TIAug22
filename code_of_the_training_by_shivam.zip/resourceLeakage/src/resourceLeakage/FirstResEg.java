package resourceLeakage;
import java.util.*;

public class FirstResEg {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) { // Resource leak: 'sc' is
													// never closed
			System.out.println("Enter an Integer:");
			int s = sc.nextInt();
			System.out.println(" Welcome to Java" + s + " times!!");
		}
		
		catch(java.util.InputMismatchException e){
			System.out.println(e);
		}
		finally{
			System.out.println("This is finally block");
		}
		// sc.close();
	}
}