package pkgList;

import java.util.*;

class emp implements Comparable<emp> {
	public int empId;
	public int salary;
	public String empName;

	public int compareTo(emp e) {
		return this.empName.length() - e.empName.length();
	}

	@Override
	public String toString() {
		return "emp [empId=" + empId + ", salary=" + salary + ", empName=" + empName + "]";
	}

	public emp(int empId, int salary, String empName) {
		super();
		this.empId = empId;
		this.salary = salary;
		this.empName = empName;
	}

}

class cmpSalarDesc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e2.salary - e1.salary;
	}
}

class cmpSalarInc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e1.salary - e2.salary;
	}
}

class cmpNameLenInc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e1.empName.length() - e2.empName.length();
	}
}

class cmpNameLenDesc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e2.empName.length() - e1.empName.length();
	}
}

class cmpIDInc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e1.empId - e2.empId;
	}
}

class cmpIDDesc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e2.empId - e1.empId;
	}
}

class cmpNameInc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e1.empName.compareTo(e2.empName);
	}
}

class cmpNameDesc implements Comparator<emp> {
	public int compare(emp e1, emp e2) {
		return e2.empName.compareTo(e1.empName);
	}
}

public class sortingEmpEx {

	public static void main(String[] args) {
		ArrayList<emp> emm = new ArrayList<emp>();
		emm.add(new emp(12, 1000000, "rahul"));
		emm.add(new emp(10, 1500000, "kartik"));
		emm.add(new emp(14, 200000, "rohan"));
		emm.add(new emp(18, 2500000, "ajay"));

		Collections.sort(emm, new cmpIDInc());
		Collections.sort(emm);
		System.out.println(emm);
	}

}
