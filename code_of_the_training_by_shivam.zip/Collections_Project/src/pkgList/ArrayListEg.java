package pkgList;
import java.util.*;
public class ArrayListEg {  
	   public static void main(String args[]){  
	      ArrayList<String> alist=new ArrayList<String>();  
	      alist.add("Steve");
	      alist.add("Tim");
	      alist.add("Lucy");
	      alist.add("Pat");
	      alist.add("Tom");
	       //displaying elements
	      System.out.println("The Original list: \n" + alist);
	      //Adding "Steve" at the fourth position
	      alist.add(3, "Steve");
	      System.out.println("After Adding Steve at the fourth position \n" + alist);
	      alist.add("Sid");//added at the end
	      System.out.println("After Adding Sid  \n" + alist);
	      alist.remove(2); //removing 3rd element
	      System.out.println("After removing 3rd element \n" + alist);
	      alist.remove("Steve"); //first occurrance of steve is removed
	      System.out.println("After removing first occurrance of steve \n" + alist);
	      alist.set(1,"Steves");
	      System.out.println("After setting steves at 1st position \n" + alist);
	      System.out.println("Index of Sid: " + alist.indexOf("Sid"));
	      System.out.println("At position 2, the element is: " + alist.get(2));
	      System.out.println("Size of ArrayList alist: " + alist.size());
	      System.out.println("Tom in the list?? "+ alist.contains("Tom"));
	      System.out.println("At last list: " + alist);
	      Collections.sort(alist);
	      System.out.println(alist);
	      
	      
	      
	   }  
	}
