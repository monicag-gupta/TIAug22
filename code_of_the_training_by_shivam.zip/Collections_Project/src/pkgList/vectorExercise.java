package pkgList;
import java.util.*;
class employee{
	private int empid;
	private String empName;
	
	employee(){
		
	}
	@Override
	public String toString() {
		return "employee [empid=" + empid + ", empName=" + empName + "]";
	}
	employee(int empid, String empName, Vector<employee> lst){
		this.empid = empid;
		this.empName = empName;
		Iterator<employee> it=lst.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
	
	
}

public class vectorExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vector<employee> list = new Vector<employee>();
		employee emp  = new employee(12, "shivam", list);
		list.add(emp);
		emp = new employee(13, "kartik", list);
		list.add(emp);
		emp = new employee(14, "rohit", list);
		list.add(emp);
		emp = new employee(15, "sahil", list);
		list.add(emp);
		
	}

}
