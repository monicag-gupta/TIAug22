package streamApiPkg;
import java.util.*;
public class sortedStream {
	public static void main(String[] args) {
		List<String> l=Arrays.asList("Hello","Extra", "World.", "Zebra", "!!","Hello" , "Java", "Coders", "World!");
		
		l.stream()
			.sorted()
			.forEach(x->System.out.print(x + "  "));
		
		new Random().ints().limit(10).sorted().forEach(x->System.out.println(x + "  "));
		new Random().ints().filter(x->(x>=100&&x<=103)).limit(50).sorted().forEach(x->System.out.print(x + "  "));
	}
	
}
