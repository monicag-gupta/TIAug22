package streamApiPkg;
import java.util.*;
import java.util.function.Function;

public class StreamApiEx {
	
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
		Function<Integer, String> fi = (x)->{
			if(x%2==0) {
				return x.toString() +": " + "Even "; 
			}
			return x.toString() +": " + "Odd ";
		};
//		List<String> ans = new ArrayList<>();
//		numbers.stream().map((x)->{
//			if(x%2==0) {
//				return x +": " + "Even "; 
//			}
//			return x.toString() +": " + "Odd ";
//		}).forEach(System.out::print);
		numbers.stream().map(fi).forEach(System.out::print);
		
	}

}
