package streamApiPkg;

import java.util.List;
import java.util.*;

public class filterEx {
	public static void main(String[] args) {
		 List<String> list = Arrays.asList("Java", "is", "not", "great", "now");
		 list.stream().filter((x)->{
			 return x.substring(0, 1).compareTo("n")!=0;
		 }).forEach(System.out::println);
	}

}
