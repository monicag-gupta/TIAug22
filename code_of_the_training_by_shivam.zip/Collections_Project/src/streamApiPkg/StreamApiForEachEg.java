package streamApiPkg;
import java.util.*;

public class StreamApiForEachEg {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("Hello"," ", "World", " ", "!!");
		l.stream()
			.map((x)->x.toUpperCase())
			.forEach(System.out::print);

	}

}