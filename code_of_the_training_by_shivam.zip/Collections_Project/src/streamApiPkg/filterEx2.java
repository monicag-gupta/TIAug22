package streamApiPkg;
import java.util.*;
public class filterEx2 {
	public static void main(String[] args) {
		List<String> Str=Arrays.asList("A","","B","C","","D","","E");
		int cnt = (int)Str.stream().filter((x)->(x.length()==0)).count();
		System.out.println(cnt);
		List<String> l=Arrays.asList("Hello","", "World.", "", "!!","Hello" , "Java", "", "World!");
		String s = l.stream()
				.filter(x-> x.length()==5)
				.findAny()
				.orElse("");
		System.out.println(s);
		
	}
}
