package streamApiPkg;
import java.util.function.*;
import java.util.*;

public class LazyEg {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("123", "67", "34", "34t","89","44");
		
		l.stream()
			.peek(System.out::print)
			.map(Integer::parseInt)
			.peek(x->System.out.print(":"+(++x) + "(Incremented):"))
			.forEach(System.out::println);

	}

}