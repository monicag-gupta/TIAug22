package streamApiPkg;

import java.util.*;
import java.util.stream.Collectors;
public class StreamAPIdistinctMap {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("Hello"," ", "World", " ", "!!","Hello" , "Java", "World");
		
		l.stream()
		.distinct()
		.peek(x->System.out.print(" Peeking: "+ x+ " : "))
		.map((x)->x.toUpperCase())
		.forEach(System.out::println);

		String s = l.stream()
				.distinct()
				//.peek(x->System.out.print(" Peeking: "+ x+ " : "))
				.map((x)->x.toUpperCase())
				.collect(Collectors.joining(", "));
				
				System.out.println(s);
				
				
				List <String> st = l.stream()
						.distinct()
						//.peek(x->System.out.print(" Peeking: "+ x+ " : "))
						.map((x)->x.toUpperCase())
						.collect(Collectors.toList());
						
						System.out.println(st);
						
			// usage of filter
						List<String> ss = l.stream()
								//.distinct()
								//.peek(x->System.out.print(" Peeking: "+ x+ " : "))
								.filter(x->!x.equalsIgnoreCase("Hello"))
								.map((x)->x.toUpperCase())
								//.collect(Collectors.joining(", "));
								.collect(Collectors.toList());
								
								System.out.println(ss);

	}

}