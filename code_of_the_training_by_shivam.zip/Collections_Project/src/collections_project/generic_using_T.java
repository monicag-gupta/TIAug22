package collections_project;
class Emp<T>
{
	T empId;
	String empName;
	public Emp(){}
	public Emp(T empId, String empName) {
		this.empId = empId;
		this.empName = empName;
	}
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + "]";
	}
	
}
public class generic_using_T {

	public static void main(String[] args) {
		Emp<Integer> e1=new Emp<>(101,"Abc");
		System.out.println(e1);
		Emp<String> e2=new Emp<>("E0012","Abc");
		System.out.println(e2);
	}

}