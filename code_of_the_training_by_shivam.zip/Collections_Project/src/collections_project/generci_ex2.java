package collections_project;
class Empp{
	Object empId;
	public String toString() {
		return "Empp Class Object with Id :" + empId;
	}
	
}
public class generci_ex2 {
	static void project1(){
		Empp e1=new Empp();
		e1.empId=101;
		e1.empId="E101";
		Integer i=(Integer)e1.empId;
		System.out.println(e1);
	}
	static void project2(){
		Empp e1=new Empp();
		e1.empId="E101";
		String s=(String)e1.empId;
		System.out.println(e1);
	}

	public static void main(String[] args) {
		project1();
		project2();
		
	}
}