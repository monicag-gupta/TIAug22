package collections_project;
class Emp3<T,U>{
	T empId;
	U empName;
	public Emp3(T empId, U empName) {
		this.empId = empId;
		this.empName = empName;
	}
	public Emp3(){}
	public String toString() {
		return "Emp3 [empId=" + empId + ", empName=" + empName + "]";
	}	
}
class Name{
	String FName;
	String LName;
	public Name(String fName, String lName) {
		FName = fName;
		LName = lName;
	}
	public Name(){}
	public String toString() {
		return FName + " " + LName ;
	}
	
	
}
public class generic_multiple_T {

	public static void main(String[] args) {
		Emp3<Integer, String> e1=new Emp3<>(101,"Abc");
		Emp3<String, String> e2=new Emp3<>("102","Abcd");
		System.out.println(e1 + "\n\n" + e2);
		Name n=new Name("Siddhant", "Modi");
		Emp3<Integer, Name> e3=new Emp3<>(103,n);
		System.out.println(e3);

	}

}