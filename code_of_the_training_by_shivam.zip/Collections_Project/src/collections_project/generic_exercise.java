package collections_project;
import java.util.*;
class find_max<T>
{
	 T a, b;
	public find_max() {
		
	}
	public find_max(T aa, T bb) {
		this.a = aa;
		this.b = bb;
		
	}
	
	public T maxx() {
		if(a instanceof Integer) {
			int vl = ((Integer) a).intValue();
			int vl2 = ((Integer) b).intValue();
			if(vl>=vl2) {
				return a;
			}
			return b;
		}
		if(a instanceof Double) {
			double vl = ((Double) a).doubleValue();
			double vl2 = ((Double) b).doubleValue();
			if(vl>=vl2) {
				return a;
			}
			return b;
		}
		if(a instanceof String) {
			String vl = ((String) a);
			String vl2 = ((String) b);
			if(vl.compareTo(vl2)>=0) {
				return a;
			}
			return b;
		}
		else {
			return b;
		}
		
	}
}

public class generic_exercise {

	public static void main(String[] args) {
		// if a>=b it will return a
		//double a = 9.8, b = 2.3;
		String  a = "s", b = "asbbs";
		find_max fm = new find_max(a, b);
		//System.out.println(fm.maxUtil());
		System.out.println(fm.maxx());
	}

}
