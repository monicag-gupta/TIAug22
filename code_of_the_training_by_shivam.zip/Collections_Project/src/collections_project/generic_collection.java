//package collections_project;
//class Emp
//{
//	int empId;
//	String empName;
//	public Emp(){}
//	public Emp(int empId, String empName) {
//		super();
//		this.empId = empId;
//		this.empName = empName;
//	}
//	public String toString() {
//		return "Emp [empId=" + empId + ", empName=" + empName + "]";
//	}
//	
//}
//public class generic_collection {
//
//	public static void main(String[] args) {
//		Emp e1=new Emp(101,"Abc");
//		System.out.println(e1);
//
//	}
//
//}