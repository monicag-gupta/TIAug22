package mapPkg;
import java.util.*;
class emp{
	private int empid;
	private String empName;
	emp(){
		
	}
	emp(int vempid, String vempName){
		empid = vempid;
		empName = vempName;
	}
	@Override
	public String toString() {
		return "emp [empid=" + empid + ", empName=" + empName + "]";
	}
}

public class mapEx {
	public static void main(String[] args) {
		
		Map<Integer, emp> mpp = new HashMap<Integer, emp>();
		mpp.put(1, new emp(1, "shivam"));
		mpp.put(13,  new emp(13, "kartik"));
		mpp.put(14,  new emp(14, "rohit"));
		mpp.put(17,  new emp(17, "aryan"));
		mpp.put(13,  new emp(13, "himanshu"));
		for (int key : mpp.keySet()) {
            System.out.println(key + ": " + mpp.get(key));
        }
		
		
		
	}

}
