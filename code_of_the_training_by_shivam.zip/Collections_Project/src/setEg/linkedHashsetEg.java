package setEg;

import java.util.*;

public class linkedHashsetEg {
	public static void main(String args[]) {
		int count[] = { 1, 3, 4, 2, 34, 22, 10, 60, 30, 22 };
		Set<Integer> set = new HashSet<Integer>();

		for (int i = 0; i < 5; i++) {
			set.add(count[i]);
		}
		// LinkedHasSet maintains the insertion order of objects.
		System.out.println("Hash Set: " + set);
		Set<Integer> Lset = new LinkedHashSet<Integer>();

		for (int i = 0; i < 5; i++) {
			Lset.add(count[i]);
		}
		System.out.println("Linked Hash Set: " + Lset);
		TreeSet sortedSet = new TreeSet<Integer>(set);
		System.out.println("The sorted list is:");
		System.out.println(sortedSet);
		System.out.println("The First element of the set is: "
				+ (Integer) sortedSet.first());
		System.out.println("The last element of the set is: "
				+ (Integer) sortedSet.last());

	}
}