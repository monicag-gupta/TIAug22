//package LambdaProj;
//
//interface MathOp{
//int operation(int x, int y);
//}
//
//public class AnonymousEx {
//	public static void main(String[] args) {
//		MathOp  add  = new MathOp() {
//			public int operation(int x, int y) {
//				return x+y;
//			}
//		};
//		MathOp sub = new MathOp() {
//			public int operation(int x, int y) {
//				return x-y;
//				
//			}
//		};
//		MathOp mul = new MathOp() {
//			public int operation(int x, int y) {
//				return x*y;
//			}
//		};
//		MathOp div = new MathOp() {
//			public int operation(int x, int y) {
//				return x/y;
//			}
//		};
//		System.out.println(add.operation(7, 10));
//		System.out.println(sub.operation(7, 10));
//		System.out.println(mul.operation(7, 10));
//		System.out.println(div.operation(75, 5));
//		
//	}
//}
