package LambdaProj;
interface FI{
	void SAM(int sword);
}
public class LambdaEg {

	public static void main(String[] args) {
		FI fi=new FI(){
			public void SAM(int sword){
				System.out.println("Implementing Sword: " + sword);
			}
		};
		fi.SAM(10);
		FI fi2=(int sword) -> System.out.println("Implementing Sword: " + sword);
		fi2.SAM(20);

	}

}
