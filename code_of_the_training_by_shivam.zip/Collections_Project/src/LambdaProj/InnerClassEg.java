package LambdaProj;
public class InnerClassEg { //InnerClassEg.class
	static class Inner { //InnerClassEg$Inner.class

		public static void main(String[] args) {
			System.out.println("Hello from inner class");

		}
	}

}