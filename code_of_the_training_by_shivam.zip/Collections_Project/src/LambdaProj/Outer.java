package LambdaProj;
interface A{ // A.class will be generated
	void fn();
}
public class Outer { // Outer.class will be generated...
	class Inner implements A{   // Outer$Inner.class will be generated
		public void fn(){
			System.out.println("Inner class implementing interface A, implements fn()");
		}
	}

	public static void main(String[] args) {
		A a=(new Outer()).new Inner();
		a.fn();
		

	}

}