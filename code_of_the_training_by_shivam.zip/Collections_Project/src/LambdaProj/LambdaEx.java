package LambdaProj;

interface MathOp{
int operation(int x, int y);
}


public class LambdaEx {
	public static void main(String[] args) {
		MathOp  add  = (x, y) -> x+y;
		MathOp sub = (x, y) -> {
			if(x>=y) {
				return x-y;
			}	
			return y-x;
		};
		MathOp mul = (x, y) -> x*y;
		MathOp div = (x, y) -> {
			return y==0?0:x/y;
		};
		System.out.println(add.operation(7, 10));
		System.out.println(sub.operation(7, 10));
		System.out.println(mul.operation(7, 10));
		System.out.println(div.operation(75, 5));
		
	}
}

