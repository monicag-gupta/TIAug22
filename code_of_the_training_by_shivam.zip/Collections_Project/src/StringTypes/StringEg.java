package StringTypes;
import java.util.*;

public class StringEg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] helloArray = {'H', 'e', 'l', 'l', 'o'};
				String s = new String(helloArray);
				System.out.println(s);//Hello
				System.out.println(s.toUpperCase());//HELLO  
				System.out.println(s.toLowerCase());//hello  
				System.out.println(s);//Hello(no change in original) 
				s="  Sachin  ";  
				System.out.println(s);//  Sachin    
				System.out.println(s.trim());//Sachin
				s="Sachin";  

				System.out.println(s.startsWith("Sa"));//true  
				System.out.println(s.endsWith("n"));//true  
				System.out.println(s.charAt(0));//S  
				System.out.println(s.length());//6  
				int a=10;  
				s=String.valueOf(a);  
				System.out.println(s+10);
				
				// String Builder Example..
				StringBuilder sb=new StringBuilder("Hello ");  
				sb.append("Java");//changed  
				System.out.println(sb);//Hello Java 
				sb.insert(1,"Java");//changed  
				System.out.println(sb);//HJavaello for sb=“Hello”
				sb.replace(1,3,"Java");  
				System.out.println(sb);//prints HJavalo for sb=“Hello”
				sb.delete(1,3);  
				System.out.println(sb);//prints Hlo for sb=“Hello”
				sb.reverse();  
				System.out.println(sb);//prints olleH for sb=“Hello”
				
				// String Buffer Example...
				StringBuffer sbb=new StringBuffer("Hello");
				sbb.append("Java");//changed  
				System.out.println(sbb);//Hello Java 
				sbb.insert(1,"Java");//changed  
				System.out.println(sbb);//HJavaello for sb=“Hello”
				sbb.replace(1,3,"Java");  
				System.out.println(sbb);//prints HJavalo for sb=“Hello”
				sbb.delete(1,3);  
				System.out.println(sbb);//prints Hlo for sb=“Hello”
				sbb.reverse();  
				System.out.println(sbb);//prints olleH for sb=“Hello”
				
	}

}
