//package excercise_weekend;
////
////class Box<T> {
////
////    private T t; // T stands for "Type"          
////
////    public void add(T t) {
////        this.t = t;
////    }
////
////    public T get() {
////        return t;
////    }
////}
////public class generic_types {
////	public static void main(String[] args) {
////        Box<Integer> integerBox = new Box<Integer>();
////        integerBox.add(new Integer(10));
////        Integer someInteger = integerBox.get(); // no cast!
////        System.out.println(someInteger);
////    }
////}
