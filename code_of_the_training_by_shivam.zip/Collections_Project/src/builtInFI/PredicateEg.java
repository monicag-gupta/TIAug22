package builtInFI;
import java.util.function.*;
import java.util.*;

public class PredicateEg {

	public static void main(String[] args) {
		Predicate<Integer> gr0=(x) -> x >= 0;
		Predicate<Integer> lt100 = (x) -> x <= 100;
		Predicate<Integer> marksChkAnd = gr0.and(lt100); //x>=0 and x<=100
		Predicate<Integer> lt0=(x) -> x < 0;
		Predicate<Integer> marksChkOr = lt0.or(x -> x > 100); //x<0 or x>100
		Scanner sc = new Scanner(System.in);
		while(true){
		System.out.println("Enter marks: (0-100): (-1 to exit)");
		int marks=sc.nextInt();
		if(marks == -1)
			break;
		System.out.println(marksChkAnd.negate().test(marks) ? "\nInvalid Marks" : "\nValid marks");
		System.out.println(marksChkOr.test(marks) ? "\nInvalid Marks" : "\nValid marks");
		}
		
 
	}

}