package builtInFI;

import java.util.function.*;
import java.util.*;

public class SupplierEg {

	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();
		names.add("Harry");
		names.add("Daniel");
		names.add("Lucifer");		
		names.add("O' Neil");
		for(String name : names){
			printNames(() -> name);
		}
	}
	private static void printNames(Supplier<String> supplier) {
		System.out.println(supplier.get());
	}
}