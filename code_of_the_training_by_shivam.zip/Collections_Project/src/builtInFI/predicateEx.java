package builtInFI;

import java.util.Scanner;
import java.util.function.Predicate;

public class predicateEx {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Predicate<Integer> oddtst = (x) -> {
			if (x == 2) {
				return true;
			}
			return x % 2 != 0;
		};
		Predicate<Integer> primetest = (x) -> {
			if (x == 1) {
				return false;
			}
			boolean flag = true;
			for (int i = 2; i < x; i++) {
				if (x % i == 0) {
					flag = false;
					break;
				}
			}
			return flag;
		};
		int n = sc.nextInt();
		Predicate<Integer> finalprmtest = oddtst.and(primetest);
		for (int i = 1; i <= n; i++) {
			if (finalprmtest.test(i)) {
				System.out.println(i);
			}
		}

	}

}
