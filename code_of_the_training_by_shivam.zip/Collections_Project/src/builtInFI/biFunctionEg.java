package builtInFI;

import java.util.function.BiFunction;

public class biFunctionEg {
	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> add = (x, y)-> (x+y);
		BiFunction<Integer, Integer, Integer> sub = (x, y)-> {
			if(x>=y) {
				return x - y;
			}
			return y - x;
	};
		BiFunction<Integer, Integer, Integer> mul = (x, y)-> (x*y);
		BiFunction<Integer, Integer, Integer> div = (x, y)-> {
			return y==0?0:x/y;
		};
		System.out.println(add.apply(12,  89));
		System.out.println(sub.apply(12,  89));
		System.out.println(mul.apply(12,  89));
		System.out.println(div.apply(84,  12));
		
	}

}
