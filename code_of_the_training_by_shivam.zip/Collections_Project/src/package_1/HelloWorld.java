package package_1;

public class HelloWorld {
	public void PublicClassPublicHello(){
		System.out.println("PublicClassPublicHello");
	}
	void PublicClassDefaultHello(){
		System.out.println("PublicClassDefaultHello");
	}
	private void PublicClassPrivateHello(){
		System.out.println("PublicClassPrivateHello");
	}
	protected void PublicClassProtectedeHello(){
		System.out.println("PublicClassProtectedHello");
	}
	
}