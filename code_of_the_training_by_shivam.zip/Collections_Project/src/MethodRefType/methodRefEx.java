package MethodRefType;

class operations{
    int add(int x, int y) {
	   return x+y;
   }
   int sub(int x, int y) {
	   if(x>=y) {
		   return x- y;
	   }
	   return y - x;
   }
   int mul(int x, int y) {
	   return x*y;
   }
   int div(int x, int y) {
	   return y==0?0:x/y;
   }
}


interface MathOp{
int operation(int x, int y);
}

public class methodRefEx {
	
	public static void main(String[] args) {
		MathOp Add =  new operations()::add;
		MathOp Sub =  new operations()::sub;
		MathOp Mul =  new operations()::mul;
		MathOp Div =  new operations()::div;
		System.out.println(Add.operation(7, 10));
		System.out.println(Sub.operation(7, 10));
		System.out.println(Mul.operation(7, 10));
		System.out.println(Div.operation(75, 5));
		
	}

}
