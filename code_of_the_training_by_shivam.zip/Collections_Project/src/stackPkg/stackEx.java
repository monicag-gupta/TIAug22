package stackPkg;
import java.util.*;

public class stackEx {
	
	public static void main(String[] args) {
		String test = "((()))";
		Stack<Character> st1 = new Stack<>();
		Stack<Character> st2 = new Stack<>();
		for(int i = 0;i<test.length();i++) {
			if(test.charAt(i)=='(') {
				st1.add(test.charAt(i));
			}
			else if(test.charAt(i)==')') {
				st2.add(test.charAt(i));
			}
			
		}
		if(st1.size()==st2.size()) {
			System.out.println("Compiled successfully.");
		}
		else {
			System.out.println("Error in () mismatch.");
		}
		
		
		
	}

}
