package stackPkg;
import java.util.*;
public class testArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> lst = new ArrayList<>();
		int val = 90;
		lst.add(val);
		lst.add(811818);
		lst.add(123);
		System.out.println(lst.get(1));
		

	}

}
