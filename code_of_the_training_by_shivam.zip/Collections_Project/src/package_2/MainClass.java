package package_2;
import package_1.*;
class HelloChild extends HelloWorld{
	void protectedMember(){
		PublicClassProtectedeHello();
	}
}

public class MainClass {

	public static void main(String[] args) {
		HelloChild h=new HelloChild();
		h.PublicClassPublicHello();
		h.protectedMember();
		

	}

}
