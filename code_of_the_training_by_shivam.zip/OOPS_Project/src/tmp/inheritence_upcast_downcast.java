package tmp;
//class PP{
//	public void google(){
//		System.out.println("PP: Google Owner");
//	}
//}
//class MChild extends PP{
//	public void google(){
//		System.out.println("MChild: Google and gmail Owner");
//	}
//	public void microsoft(){
//		System.out.println("MChild : Microsoft Owner");
//	}
//}
//class FChild extends PP{
//	public void google(){
//		System.out.println("FChild: Google and Google+ Owner");
//	}
//	public void oracle(){
//		System.out.println("FChild : Oracle Owner");
//	}
//}
//public class inheritence_upcast_downcast {	
//	public static void main(String[] args) {
//		PP PP1 = new MChild(); //upcasting //generalization
//		PP1.google(); //MChild's google function is executed : Specialization PPrt 1
//		if(PP1 instanceof FChild){
//			FChild fc1=(FChild)PP1; //safe downcasting  //specialization
//			fc1.oracle();
//			fc1.google();
//		}
//		else if(PP1 instanceof MChild){
//			MChild m1=(MChild)PP1; //safe downcasting  //specialization
//			m1.microsoft();
//			m1.google();
//		}
//	}
//}

class PP{
	public void google(){
		System.out.println("Pa: Google Owner");
	}
	public void IBM(){
		System.out.println("Pa: IBM Owner");
	}
}
class MChild extends PP{
	public void google(){
		System.out.println("MChild: Google and gmail Owner");
	}
	public void microsoft(){
		System.out.println("MChild : Microsoft Owner");
	}
}
class FChild extends PP{
	public void google(){
		System.out.println("FChild: Google and Google+ Owner");
	}
	public void oracle(){
		System.out.println("FChild : Oracle Owner");
	}
}
class Framework{
	PP p;
	public void input(PP p){
		this.p=p;
	}
	public void print(){
		p.google();
		if(p instanceof MChild){
			MChild m=(MChild)p;
			m.microsoft();
		}
		if(p instanceof FChild){
			FChild m=(FChild)p;
			m.oracle();
		}
	}
}
public class inheritence_upcast_downcast {	
	public static void main(String[] args) {
		MChild m1=new MChild();
		Framework f=new Framework();
		f.input(m1);
		f.print();
		f.input(new FChild());
		f.print();
		
	}
}
