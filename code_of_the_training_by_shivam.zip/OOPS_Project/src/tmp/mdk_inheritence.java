package tmp;

import java.util.Scanner;

class mdk{
	public void OOPS(){
		System.out.println("Object Oriented Programming System.");
	}
	public void AOPS(){
		System.out.println("Aspect Oriented Programming Systems");
	}
}
class mdkwin extends mdk{
	public void OOPS() {
		System.out.println("Windows Object Orientd Programming System.");
		
	}
	public void AOPS() {
		System.out.println("Windows Aspect Oriented Programming System.");
	}
}

class mdkmac extends mdk{
	public void OOPS() {
		System.out.println("MacOS Object Orientd Programming System.");
		
	}
	public void AOPS() {
		System.out.println("MacOS Aspect Oriented Programming System.");
	}
}
class OS{
	public mdk mmddkk;
	public void osanc() {
		System.out.println("This is OS class.");
	}
}
class winos extends OS{
	public void osanc() {
	  System.out.println("The os is windows");
	}
}
class macOs extends OS{
	public void osanc() {
	  System.out.println("The os is macos");
	}
}
class others extends OS{
	
}

class browser {
	void perform() {
		System.out.println("Enter your OS");
		System.out.println("1. MacOS");
		System.out.println("2. Windows");
		System.out.println("3. Others");
		int choice = 0;
		Scanner sc = new Scanner (System.in);
		choice = sc.nextInt();
		if(choice==1) {
			mdk an = new mdkmac();
			mdkmac mc = (mdkmac)an;
			OS os = new macOs();
			macOs ansos = (macOs)os;
			ansos.osanc();
			mc.OOPS();
			mc.AOPS();
			
		}
		else if(choice==2) {
			mdk an = new mdkwin();
			mdkwin mc = (mdkwin)an;
			OS os = new winos();
			winos ansos = (winos)os;
			ansos.osanc();
			mc.OOPS();
			mc.AOPS();
		}
		else {
			mdk an = new mdk();
			OS os = new OS();
			os.osanc();
			an.OOPS();
			an.AOPS();
			
			
			
		}
	}
}
public class mdk_inheritence{
	public static void main(String arg[]) {
		browser br = new browser();
		br.perform();
	}
}