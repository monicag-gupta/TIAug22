package tmp;
interface GF{
	void mercedes();
	default void audi(){
		System.out.println("Audi by GF: default");
	}
}
interface PPa extends GF{
	void BMW();
	default void skoda(){
		System.out.println("skoda by PPa: default");
	}
}
interface Ma extends GF{
	void Lamborghini();
	default void skoda(){
		System.out.println("skoda by Ma: default");
	}
}

class A implements PPa, Ma{
	public void mercedes(){
		System.out.println("Mercedes Benz by A from GF, PPa, Ma");
	}
	public void BMW(){
		System.out.println("BMW by A from PPa");
	}
	public void Lamborghini(){
		System.out.println("Lamborghini by A from Ma");
	}
	// here we are overriding the skoda function which is being inherited from PPa and Ma class 
	// and there is conflict..
	public void skoda(){
		System.out.println("skoda by A: default from PPa, Ma");
	}
	
}
public class diamond_problem {

	public static void main(String[] args) {
		PPa pa=new A();
		pa.mercedes();
		pa.BMW();
		pa.audi();
		pa.skoda();
		Ma ma=new A();
		ma.mercedes();
		ma.Lamborghini();
		ma.audi();
		ma.skoda();
		GF gf=new A();
		gf.mercedes();
		gf.audi();
		A obja = new A();
		obja.mercedes();
		obja.Lamborghini();
		obja.BMW();
		obja.audi();
		obja.skoda();
	}

}
