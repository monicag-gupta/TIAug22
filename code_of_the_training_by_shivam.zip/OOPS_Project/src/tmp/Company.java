package tmp;

public class Company {
	private String GSTNo;
	private String CompName;
	private int turnOver;
	private int noofEmpl;
	public String getGSTNo() {
		return GSTNo;
	}
	public void setGSTNo(String gSTNo) {
		GSTNo = gSTNo;
	}
	public String getCompName() {
		return CompName;
	}
	public void setCompName(String compName) {
		CompName = compName;
	}
	public int getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(int turnOver) {
		this.turnOver = turnOver;
	}
	public int getNoofEmpl() {
		return noofEmpl;
	}
	public void setNoofEmpl(int noofEmpl) {
		if(noofEmpl<=0) {
			System.out.println("-ve no. of employees is not allowed");
			this.noofEmpl = 0;
		}
		else {
			this.noofEmpl = noofEmpl;	
		}
	}
	public void input(String gst, String cname, int turnover, int noofempl) {
		setGSTNo(gst);
		setCompName(cname);
		setTurnOver(turnover);
		setNoofEmpl(noofempl);
	}
	@Override
	public String toString() {
		return "Company [GSTNo=" + GSTNo + ", CompName=" + CompName + ", turnOver=" + turnOver + ", noofEmpl="
				+ noofEmpl + "]";
	}
	public static void main(String args[]) {
		Company cmp = new Company();
		cmp.input("GST10000000", "Sample_Company", 100000000, -100);
		System.out.println(cmp);
		
	}
}
