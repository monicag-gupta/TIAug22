package tmp;
interface OOSS{ //100% abstraction
	void cmdLine(); 
	void dir();
	void FS();
}
class WinOOSS implements OOSS{
	public void cmdLine(){
		System.out.println("Cmd");
	}
	public  void dir(){
		System.out.println("Dir System");
	}
	public void FS(){
		System.out.println("NTFS: File System");
	}
}
class MacOOSS implements OOSS{
	public void cmdLine(){
		System.out.println("Terminal");
	}
	public  void dir(){
		System.out.println("folder System");
	}
	public void FS(){
		System.out.println("Inode File System");
	}
}
public class interfaccc {
	public void workingOOSS(OOSS os){
		os.cmdLine();
		os.dir();
		os.FS();
	}

	public static void main(String[] args) {
		
		new interfaccc().workingOOSS(new WinOOSS());

	}

}