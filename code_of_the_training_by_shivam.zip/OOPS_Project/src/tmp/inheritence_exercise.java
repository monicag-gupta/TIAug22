package tmp;

class employee{
	private int empId;
	private String empName;
	private int salary;
	public void input(int empid, String empname, int sal) {
		setEmpId(empid);
		setEmpName(empname);
		setSalary(sal);
	}
	public void display() {
		System.out.println("The details of employee are empId:  "+getEmpId()+", empName: "+getEmpName()+", salary: "+getSalary());
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
}

class tl extends employee{
	private int noOfTeamMembers;
	public int getNoOfTeamMembers() {
		return noOfTeamMembers;
	}
	public void setNoOfTeamMembers(int noOfTeamMembers) {
		this.noOfTeamMembers = noOfTeamMembers;
	}
	public void input(int empid, String empname, int sal, int tmm) {
		setEmpId(empid);
		setEmpName(empname);
		setSalary(sal);
		this.noOfTeamMembers = tmm;
	}
	public void display() {
		System.out.println("The details of TL are empId:  "+getEmpId()+", empName: "+getEmpName()+", salary: "+getSalary()+", no of team members: "+noOfTeamMembers);
	}
}

class pm extends employee{
	private int noOfProjects;

	public int getNoOfProjects() {
		return noOfProjects;
	}

	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}
	public void input(int empid, String empname, int sal, int npp) {
		setEmpId(empid);
		setEmpName(empname);
		setSalary(sal);
		noOfProjects = npp;
	}
	public void display() {
		System.out.println("The details of PM are empId:  "+getEmpId()+", empName: "+getEmpName()+", salary: "+getSalary()+", no of projects are: "+noOfProjects);
	}
	
}

public class inheritence_exercise {
	public static void main(String args[]) {
		//employee emp = new pm();
		pm pmm = new pm();
		pmm.input(23, "rohit", 100000, 3);
		pmm.display();
		tl tll = new tl();
		tll.input(45, "Virat", 100000, 10);
		tll.display();
		
	//	emp.input(0, null, 0);
	}

}
