package tmp;
// date is: 02/08/2022
// author @shivam
public class Student {
	private int stdID;
	private String stdName;
	private String course;
	public int getStdID() {
		return stdID;
	}
	public void setStdID(int stdID) {
		this.stdID = stdID;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	
	public String toString(){
		return "The Student details are: id is "+stdID+" name "+ 
				stdName+" course enrolled in " +course+" fees is "+fees;
	}
	


	private int fees;
	//private int fine;
	public void input(int stdid, String stname, String crs, int fee) {
		if(fee<=0) {
			fees = 200;
		}
		else {
			fees = fee;
		}
		if(stdid<=100) {
			setStdID(100);
		}
		else {
			setStdID(stdid);
		}
		setStdName(stname);
		setCourse(crs);
	}
	public void output() {
		System.out.println("The id is: "+stdID+", name is "+stdName+", the course is: "+course+", fees is: " +fees);
	}
	
	public static void main(String args[]) {
		Student st = new Student();
		st.input(105, "kartik", "java", 500);
		st.output();
		System.out.println(st);
	}
	
	
	
	
}
