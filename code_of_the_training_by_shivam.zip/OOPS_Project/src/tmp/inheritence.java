//package tmp;
//class PP{
//	public void google(){
//		System.out.println("PP: Google Owner");
//	}
//}
//class MChild extends PP{
//	public void google(){
//		System.out.println("MChild: Google and gmail Owner");
//	}
//	public void microsoft(){
//		System.out.println("MChild : Microsoft Owner");
//	}
//}
//class FChild extends PP{
//	public void google(){
//		System.out.println("FChild: Google and Google+ Owner");
//	}
//	public void oracle(){
//		System.out.println("FChild : Oracle Owner");
//	}
//}
//public class inheritence {	
//	public static void main(String[] args) {
//		MChild c1=new MChild();
//		c1.microsoft();
//		c1.google();
//		FChild c2=new FChild();
//		c2.google();
//		c2.oracle();
//	}
//}