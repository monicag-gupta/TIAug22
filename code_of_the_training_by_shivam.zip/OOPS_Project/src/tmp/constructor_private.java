package tmp;
class Connection{
	int x;
	public void fn(){
		System.out.println("Working fn of Connection with value of x as: " +x);
	}
	private Connection(){
		System.out.println("Connection Established");
	}
	private Connection(int x){
		this.x=x;
		System.out.println("Connection Established with x: " + x);
	}
	public static Connection getConnection(int x){
		return new Connection(x);
	}
	public static Connection getConnection(){
		return new Connection();
	}
	
}
public class constructor_private {

	public static void main(String[] args) {
		Connection c=Connection.getConnection();
		c.fn();
		Connection c2=Connection.getConnection(85);
		c2.fn();
		c.fn();

	}

}