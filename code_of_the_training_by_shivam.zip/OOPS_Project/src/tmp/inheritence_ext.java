//package tmp;
//class PP{
//	public void google(){
//		System.out.println("PP: Google Owner");
//	}
//}
//class MChild extends PP{
//	public void google(){
//		System.out.println("MChild: Google and gmail Owner");
//	}
//	public void microsoft(){
//		System.out.println("MChild : Microsoft Owner");
//	}
//}
//class FChild extends PP{
//	public void google(){
//		System.out.println("FChild: Google and Google+ Owner");
//	}
//	public void oracle(){
//		System.out.println("FChild : Oracle Owner");
//	}
//}
//public class inheritence_ext {	
//	public static void main(String[] args) {
//		PP PP1 = new MChild(); //upcasting //generalization
//		PP1.google(); //MChild's google function is executed : Specialization PPrt 1
//		MChild m1=(MChild)PP1; //downcasting  //specialization
//		m1.microsoft();
//		m1.google();
//		
//		
//		
//	}
//}