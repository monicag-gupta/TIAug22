//package tmp;
//interface GF{
//	void mercedes();
//}
//interface PPA extends GF{
//	void BMW();
//}
//interface Ma extends GF{
//	void Lamborghini();
//}
//
//class A implements PPA, Ma{
//	public void mercedes(){
//		System.out.println("Mercedes Benz by A from GF, PPA, Ma");
//	}
//	public void BMW(){
//		System.out.println("BMW by A from PPA");
//	}
//	public void Lamborghini(){
//		System.out.println("Lamborghini by A from Ma");
//	}
//	
//}
//public class multiple_inheritance {
//
//	public static void main(String[] args) {
//		PPA pa=new A();
//		pa.mercedes();
//		pa.BMW();
//		Ma ma=new A();
//		ma.mercedes();
//		ma.Lamborghini();
//		GF gf=new A();
//		gf.mercedes();
//		A Ashutosh = new A();
//		Ashutosh.mercedes();
//		Ashutosh.Lamborghini();
//		Ashutosh.BMW();
//	}
//
//}
