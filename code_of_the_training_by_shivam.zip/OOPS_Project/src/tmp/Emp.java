package tmp;
public class Emp {
	public int empId; //abstracted attributes
	public String name;
	private int sal;  //encapsulated attribute
	public void setSal(int s){ //setter property
		if(s<=0){
			s=0;
		}
		sal=s;
	}
	public int getSal(){ //getter property
		return sal;
	}
	public void print(){ //behavior
		System.out.println("The Emp details are: " + name + " with ID: " + empId + " getting salary: " + sal);
	}
public static void main(String[] args) {
		Emp e1 = new Emp();
		e1.name = "Abc";
		e1.empId = 123;
		e1.setSal(-20);
		e1.print();
		
		

	}

}