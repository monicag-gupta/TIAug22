package tmp;
//Runtime Polymorphism / Dynamic Polymorphism
import java.util.Scanner;

class Parent{
	public void fn(){
		System.out.println("I am fn() in Parent");
	}
}
class ChildPa1 extends Parent{
	public void fn(){
		System.out.println("I am fn() in ChildPa1");
	}
}
class ChildPa2 extends Parent{
	public void fn(){
		System.out.println("I am fn() in ChildPa2");
	}
}
class ChildPa3 extends Parent{ //static polymorphism in inheritance
	public void fn(int x){
		System.out.println("I am fn(int x) in ChildPa3");
	}
}
public class compile_and_rt {
	public void fnn(Parent p){ //until runtime fnn does not know if p is of Parent, childPa1 or Childpa2
		p.fn();
	}

	public static void main(String[] args) {
		compile_and_rt pobj=new compile_and_rt();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter choice from (1. ChildPa1, 2. ChildPa2) : ");
		int ch=sc.nextInt();
		if(ch==1)
			pobj.fnn(new ChildPa1());
		else if(ch==2)
			pobj.fnn(new ChildPa2());
		else
			pobj.fnn(new Parent());
		ChildPa3 child=new ChildPa3();
		child.fn();
		child.fn(3);
			

	}

}
