package tmp;

class animal{
	public void eat() {
	   System.out.println("Animal is eating.");
	}
	public void sleep() {
		System.out.println("The animal sleeps.");
	}
}
class dog extends animal{
	
	public void bark() {
		System.out.println("The dog is barking.");
	}
	public void eat() {
		System.out.println("The dog is eating.");
	}
	
}
class cat extends animal{
	public void meow() {
		System.out.println("The cat makes a sound of meow.");
	}
	
}

class trainer{
	void trainAnimal(animal aa) {
		if(aa instanceof dog) {
			dog dg = (dog)aa;
			dg.bark();
			dg.eat();
			dg.sleep();
			
		}
		else if(aa instanceof cat) {
			cat ct = (cat)aa;
			ct.meow();
		    ct.eat();
		    ct.sleep();
			
		}
		else {
			aa.sleep();
			aa.eat();
		}
	}
}

public class inhet_ex {
	public static void main(String args[]) {
		animal  aa = new dog();
		trainer tt = new trainer();
		tt.trainAnimal(aa);
	}
}
