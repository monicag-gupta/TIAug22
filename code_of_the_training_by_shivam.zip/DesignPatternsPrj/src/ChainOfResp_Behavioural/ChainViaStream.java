package ChainOfResp_Behavioural;
import java.util.function.*;
import java.util.*;

public class ChainViaStream {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("First","Second","Third","Fourth","Second");
		l.stream().sorted().distinct().forEach(System.out::println);
	}

}