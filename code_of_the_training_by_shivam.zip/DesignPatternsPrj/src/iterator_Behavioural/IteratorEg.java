package iterator_Behavioural;

import java.util.*;


public class IteratorEg {

	public static void main(String[] args) {
		List<String> l = Arrays.asList("First","Second","Third","Fourth","Second");
		Iterator<String> i=l.iterator();
		while(i.hasNext())
			System.out.println(i.next());

	}

}