package bridge_Structural;

public interface HouseInterface {
	public void niceHouse();
}
