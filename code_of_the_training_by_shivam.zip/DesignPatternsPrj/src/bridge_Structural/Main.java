package bridge_Structural;

public class Main {
	public static void main(String[] args) {

		Land l = new Land(new House(), new PlayArea());
		l.getHouse().niceHouse();
		l.getPlayArea().playGround();
	}
}