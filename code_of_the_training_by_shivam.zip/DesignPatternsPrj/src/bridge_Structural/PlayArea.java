package bridge_Structural;

public class PlayArea implements PlayAreaInterface{
	public void playGround(){
		System.out.println("This is the play ground for all kids");
	}
}