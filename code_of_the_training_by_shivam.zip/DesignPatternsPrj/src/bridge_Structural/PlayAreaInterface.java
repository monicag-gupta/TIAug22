package bridge_Structural;

public interface PlayAreaInterface {
public void playGround();
}
