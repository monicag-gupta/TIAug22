package bridge_Structural;

public class Land {
	HouseInterface house;
	PlayAreaInterface playArea;

	public Land(HouseInterface house, PlayAreaInterface playArea) {

		this.house = house;
		this.playArea = playArea;
	}

	public HouseInterface getHouse() {
		return house;
	}

	public PlayAreaInterface getPlayArea() {
		return playArea;
	}
	
}
