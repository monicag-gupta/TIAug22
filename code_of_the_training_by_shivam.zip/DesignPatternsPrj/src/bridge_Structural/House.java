package bridge_Structural;


public class House implements HouseInterface{
	public void niceHouse(){
		System.out.println("This is a nice house");
	}
}
