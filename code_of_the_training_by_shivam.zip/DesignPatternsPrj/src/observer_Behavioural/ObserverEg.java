package observer_Behavioural;
import java.io.*;
class Th implements Runnable{
	public void run(){
		String s;
		for(int i=0;i<5;i++){
			s="\nStatus: " + i + " for thread: " + Thread.currentThread().getName();
			System.out.print(s);
			try {
				FileOutputStream f= new FileOutputStream(new File("/Users/Shivam/shivam_tr/status.txt"),true);
				f.write(s.getBytes());
				f.close();
				Thread.sleep(200);
			}
			catch(Exception e){}
		}
	}
}
public class ObserverEg {

	public static void main(String[] args) {
		Thread th1=new Thread(new Th(),"T1");
		Thread th2=new Thread(new Th(),"T2");
		Thread th3=new Thread(new Th(),"T3");
		th1.start();
		th2.start();
		th3.start();

	}

}