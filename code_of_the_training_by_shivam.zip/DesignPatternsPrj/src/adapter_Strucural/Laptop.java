package adapter_Strucural;
interface Lappy{
	public void run();
}
public class Laptop implements Lappy {
	public void run(){
		System.out.println("I am running on electricity");
	}
}