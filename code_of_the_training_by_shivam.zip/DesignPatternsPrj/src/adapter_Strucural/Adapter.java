package adapter_Strucural;

public class Adapter {
	Current c;
	Lappy l;
	public Adapter(Current c, Lappy l) {
		this.c = c;
		this.l = l;
	}
	public void swithOn(){
		c.givesPower();
		l.run();
	}
	
}