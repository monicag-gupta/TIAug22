package adapter_Strucural;

public class Main {

	public static void main(String[] args) {
		Electricity e=new Electricity();
		Laptop l=new Laptop();
		Adapter a=new Adapter(e,l);
		a.swithOn();

	}

}