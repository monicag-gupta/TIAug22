package adapter_Strucural;

interface Current{
	void givesPower();
}
public class Electricity implements Current {
public void givesPower(){
	System.out.println("Provide power!");
}
}
