package facade_Structural;

interface iPrepare {
	void getPartyArea();

	void food();

	void invite();
}

class Organizer {
	public void area() {
		System.out.println("Party area fit for occasion");
	}

	public void vegFood() {
		System.out.println("Veg food for occasion");
	}
}
class Prepare implements iPrepare {
	Organizer o;

	Prepare(Organizer o) {
		this.o = o;
	}

	public void getPartyArea() {
		o.area();
	}

	public void food() {
		o.vegFood();
	}

	public void invite() {
		System.out.println("Invite for occasion");
	}
}

public class FacadeEg {
	public static void main(String[] args) {

		Prepare p = new Prepare(new Organizer());
		p.getPartyArea();
		p.food();
		p.invite();
	}
}