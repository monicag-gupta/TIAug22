package proxy_Structural;
class Main{
	void fnA(String s){
		System.out.println("Processing : "+ s);
	}
}
class ProxyMain{			
	Main m;
	ProxyMain(){
		m=new Main();
	}
	void fnA(String s){
		m.fnA(s);
	}
}
public class ProxyEg {

	public static void main(String[] args) {
		ProxyMain p=new ProxyMain();
		p.fnA("Hello");

	}

}