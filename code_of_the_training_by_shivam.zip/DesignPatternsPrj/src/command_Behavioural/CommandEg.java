package command_Behavioural;
class A{
	public void fn(){
		System.out.println("I am fulfilling the command when called");
	}
}

public class CommandEg {

	public static void main(String[] args) {
		new A().fn();

	}

}