module DesignPatternsPrj {
}