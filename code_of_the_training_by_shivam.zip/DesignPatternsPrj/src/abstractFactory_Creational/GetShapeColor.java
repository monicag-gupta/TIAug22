package abstractFactory_Creational;

public class GetShapeColor {
	
	public Shape getShape(String s){
		return new GetShape().getShape(s);
	}
	public Color getColor(String s){
		return new GetColor().getColor(s);
	}
}
