package abstractFactory_Creational;

public class Red implements Color{
	public void drawColor(){
		System.out.println("Red color used in drawing");
	}
}
