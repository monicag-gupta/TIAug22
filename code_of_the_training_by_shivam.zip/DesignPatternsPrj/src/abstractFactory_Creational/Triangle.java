package abstractFactory_Creational;

public class Triangle implements Shape{
public void drawShape(){
	System.out.println("Draw Triangle");
}
}
