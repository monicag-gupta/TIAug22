package abstractFactory_Creational;

public class GetColor {
	public void getColor(Color s){
		s.drawColor();
	}
	public Color getColor(String s){
		if(s.equals("Red"))
			return new Red();
		else
			return new Green();
	}

}