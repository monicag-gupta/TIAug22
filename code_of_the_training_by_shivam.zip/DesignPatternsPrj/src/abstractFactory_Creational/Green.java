package abstractFactory_Creational;

public class Green implements Color{
	public void drawColor(){
		System.out.println("Green color used in drawing");
	}
}