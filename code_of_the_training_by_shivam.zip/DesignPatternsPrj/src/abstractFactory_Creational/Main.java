package abstractFactory_Creational;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		GetShapeColor g=new GetShapeColor();
		System.out.println("Which shape (Triangle, Square)?");
		String s=sc.nextLine();
		System.out.println("Which Color(Red/Green)?");
		String c=sc.nextLine();
		g.getShape(s).drawShape();
		g.getColor(c).drawColor();

	}

}