package abstractFactory_Creational;

public class GetShape {
	
	public void getShape(Shape s){
		s.drawShape();
	}
	public Shape getShape(String s){
		if(s.equals("Triangle"))
			return new Triangle();
		else
			return new Square();
	}
}