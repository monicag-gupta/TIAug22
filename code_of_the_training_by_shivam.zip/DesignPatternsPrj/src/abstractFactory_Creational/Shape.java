package abstractFactory_Creational;

public interface Shape {
	 void drawShape();
}
