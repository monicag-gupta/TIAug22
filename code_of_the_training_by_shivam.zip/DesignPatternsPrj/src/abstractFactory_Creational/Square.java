package abstractFactory_Creational;

public class Square implements Shape{
	public void drawShape(){
		System.out.println("Draw Square");
	}
	}