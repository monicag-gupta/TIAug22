package abstractFactory_Creational;

public interface Color {
	void drawColor();
}