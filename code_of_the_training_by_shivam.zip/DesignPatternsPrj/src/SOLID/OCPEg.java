package SOLID;
// open closed principle
class InOCP{
	public void fn(){
		System.out.println("InOCP : fn()");
	}
}
class Ch extends InOCP{
	public void fn(){
		System.out.println("Ch : InOCP : fn()");
	}
}
public class OCPEg {
	public static void main(String[] args) {
		InOCP i=new InOCP();
		i.fn();
		i=new Ch();
		i.fn();

	}

}