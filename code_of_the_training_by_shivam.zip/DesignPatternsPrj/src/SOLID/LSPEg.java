package SOLID;
import java.util.*;
class Bird{
	String nm;
	void eat(){
		System.out.println("A Bird named: " + nm + " is eating");
	}
//	void fly(){
//		System.out.println("A Bird named: " + nm + " is flying");
//	}
}
class FlyingBird extends Bird{
	FlyingBird(String n){
		nm=n;
	}
	void fly(){
		System.out.println("A Bird named: " + nm + " is flying");
	}
}
class NonFlyingBird extends Bird{
	NonFlyingBird(String n){
		nm=n;
	}
//	void fly(){
//		throw new ArithmeticException("Sorry, We cannot fly");
//	}
}

public class LSPEg {

	public static void main(String[] args) {
		List<Bird> l=Arrays.asList(
				new FlyingBird("Crow"), new NonFlyingBird("Ostrich"),new FlyingBird("Parrot"));
		fn(l);
	}
	static void fn(List<Bird> l){
		for(Bird b : l){
			b.eat();
			if(b instanceof FlyingBird){
				FlyingBird f=(FlyingBird)b;
				f.fly();			
			}
			
		}
	}

}
