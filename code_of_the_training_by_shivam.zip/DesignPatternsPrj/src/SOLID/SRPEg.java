package SOLID;
class NotInSRP{
	void add(int x, int y){
		System.out.println(x+y);
	}
	void mul(int x, int y){
		System.out.println(x*y);
	}
}
class InSRP{
	void add(int x, int y){
		System.out.println(x+y);
	}
}
public class SRPEg {
	public static void main(String[] args) {
		NotInSRP n=new NotInSRP();
		n.add(5, 6);
		n.mul(7, 8);
		InSRP m=new InSRP();
		m.add(5, 6);
	}
}