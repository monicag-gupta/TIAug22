package MVC;
class EmpModel{
	public int EmpId;
	public String EmpName;
	public EmpModel(int empId, String empName) {
		EmpId = empId;
		EmpName = empName;
	}
}
class EmpView{
	public void View(EmpModel e){
		System.out.println(e.EmpName + " is having the ID as : " + e.EmpId);
	}
}
class EmpController{
	public void request(int empId, String empName){
		EmpModel e=new EmpModel(empId, empName);
		EmpView v=new EmpView();
		v.View(e);
	}
}
public class MVCEg {
	public static void main(String[] args) {
		EmpController e=new EmpController();
		e.request(101, "Abc");

	}

}