package flyweight_Structural;
class A{
	public void fnA(){
		System.out.println("This is A: fnA()");
	}
	public void fnB(){
		System.out.println("This is A: fnB()");
	}
}
class UseA{
	A a;
	UseA(A a){
		this.a=a;
	}
	public void fnA(){
		a.fnA();
	}
}
class UseB{
	A a;
	UseB(A a){
		this.a=a;
	}
	public void fnB(){
		a.fnB();
	}
}
class Use{
	void fn(){
		A a=new A();
		UseA ua=new UseA(a);
		ua.fnA();
		UseB ub=new UseB(a);
		ub.fnB();
	}
}
public class FlyweightEg {

	public static void main(String[] args) {
		Use u=new Use();
		u.fn();

	}

}