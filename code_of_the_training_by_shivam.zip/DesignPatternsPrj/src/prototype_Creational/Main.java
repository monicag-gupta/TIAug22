package prototype_Creational;

public class Main {
public static void main(String[] args) {
	PrototypeOfOriginal p=new PrototypeOfOriginal();
	//Original p=new Original();
	System.out.println(p.getString("Hello"));
	System.out.println(p.getString("Abc"));
	
}
}
