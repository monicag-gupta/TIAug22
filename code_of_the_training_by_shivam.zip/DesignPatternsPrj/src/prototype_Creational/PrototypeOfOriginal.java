package prototype_Creational;

public class PrototypeOfOriginal {
	public String getString(String s) {
		if (s.equals("Hello")) {
			return "Invalid string hello!";
		} else {
			return new Original().getString(s);
		}

	}
}

