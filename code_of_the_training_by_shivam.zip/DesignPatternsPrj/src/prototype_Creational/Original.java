package prototype_Creational;

public class Original {
	public String getString(String s) {
		return "From Original class : " + s;
	}
}