package composite_Structural;
class Person{
	String name;
	Address address;
	
	public Person(String name, String address) {
		this.name = name;
		this.address = new Address(address);
	}
	public String toString() {
		return "Person [name=" + name + ", address=" + address.getAddress() + "]";
	}
	
}
class Address{
	String a;
	Address(String a){this.a=a;}
	public String getAddress(){
		return ("\nThe address is: "+a + "\n");
	}
}
public class CompositeEg {

	public static void main(String[] args) {
		Person p=new Person("Abc", "Delhi");
		System.out.println(p);

	}

}