package mediator_Behavioural;
class Boss{
	Phone p;
	Boss(Phone p){this.p=p;}
}
class Phone{
	public Emp call(){
		return new Emp();
	}
}
class Emp{
	void dev(){
		System.out.println("Status of work");
	}
}
public class MediatorEg {
	public static void main(String[] args) {
		Boss b=new Boss(new Phone());
		b.p.call().dev();
	}
}