package singleton_Creational;

public class SingleObject {
	private SingleObject(){}
	static SingleObject obj;
	public String msg;
	public static SingleObject getSingleObject(){
		if(obj == null){
			obj=new SingleObject();
		}
		return obj;
	}
	

}