package singleton_Creational;

public class Main {
	public static void main(String[] args) {
		SingleObject o1 = SingleObject.getSingleObject();
		o1.msg="Hello from O1";
		SingleObject o2 = SingleObject.getSingleObject();
		o2.msg="Hello from O2";
		System.out.println(o1.msg); //Hello from O2
		//Since only one obj is being pointed by o1 and o2
		//so the msg will be the last updated msg from 
		//any of the objects.
		System.out.println(o1==o2?"O1 is equal to o2":"O1 is not equal to o2");
		
		
		// another example...
//		SingleObject o1 = SingleObject.getSingleObject();
//		o1.msg="Hello from O1";
//		SingleObject o2 = SingleObject.getSingleObject();
//		o2.msg="Hello from O2";
//		System.out.println(o1.msg); //Hello from O2
//		//Since only one obj is being pointed by o1 and o2
//		//so the msg will be the last updated msg from 
//		//any of the objects.

	}
}
