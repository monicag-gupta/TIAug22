package decorator_Structural;
interface House{
	void niceHouse();
}
class CeramicDecorators{
	public void decorate(){
		System.out.println("Interior decorations out of ceramic material");
	}
}
class HousePlan implements House{
	public void niceHouse(){
		new CeramicDecorators().decorate();
		System.out.println("Nice decorated House");
	}
}
public class DecoratorEg {

	public static void main(String[] args) {
		House h=new HousePlan();
		h.niceHouse();

	}

}