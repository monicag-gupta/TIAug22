package memento_Behavioural;
class Th implements Runnable{
	public void run(){
		for(int i=0;i<5;i++){
			System.out.println("Status: " + i + " for thread: " + Thread.currentThread().getName());
			try{
				Thread.sleep(200);
			}
			catch(Exception e){}
		}
	}
}
public class MementoEg {

	public static void main(String[] args) {
		Thread th1=new Thread(new Th(),"T1");
		Thread th2=new Thread(new Th(),"T2");
		Thread th3=new Thread(new Th(),"T3");
		th1.start();
		th2.start();
		th3.start();
	}}