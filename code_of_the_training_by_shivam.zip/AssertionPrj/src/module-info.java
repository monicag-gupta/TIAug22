module AssertionPrj {
}