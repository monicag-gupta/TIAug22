package daos;
import java.sql.*;
import java.util.*;

import dtoForPrj.MovieDTO;
import dtoForPrj.RatingDTO;
import dtoForPrj.ReviewDTO;

public class DAOForMovie {
	Connection con;
	public DAOForMovie(){
		con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/MovieDB", "root", "password");
			// here MovieDB is database name, root is username and password
		}
		catch(Exception e)
		{}
	}
	public int addMovie(MovieDTO mvi) {
		// TODO Auto-generated method stub
		Statement stmt;
		int s = 0;
		String query = "insert into movie ( movie_name, Summary, cast, Genre, Average_rating, user_id) values ( "+ 
				mvi.beautify(mvi.getMovie_name())
				+ ", " + mvi.beautify(mvi.getSummary()) + ", "+mvi.beautify(mvi.getCast())+ ", " + mvi.beautify(mvi.getGenre())+
				", "+ mvi.getAverage_rating() + ", "+ mvi.getUser_id() + ")";
		//System.out.println(query);
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(query);
		}
		catch(Exception e){
			
			
		}
		return s;
	}
	public int updateMovie(MovieDTO e)
	{
		Statement stmt;
		int s=0;
		try {

//		
			
			String query = ("Update movie set movie_name ="+e.beautify(e.getMovie_name()) + ", Summary = "+ e.beautify(e.getSummary()) + ", cast = "+ e.beautify(e.getCast())+", Genre = " + e.beautify(e.getGenre()) + ", Average_rating = "+e.getAverage_rating()+", user_id =  " +e.getUser_id()+ " where movie_id="+e.getMovie_id());
			stmt = con.createStatement();
			s = stmt.executeUpdate(query);
			
			
		} catch (Exception e1) {
			System.out.print(e1);
		}
		return s;
	}
	public int addReview(ReviewDTO rvd) {
		// TODO Auto-generated method stub
		Statement stmt;
		int s = 0;
		String query = "insert into review ( movie_id, Review, user_id ) values ( "+ 
				rvd.getMovie_id()
				+ ", " + rvd.beautify(rvd.getReview()) + ", "+rvd.getUser_id() + ")";
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(query);
		}
		catch(Exception e){
			
			
		}
		return s;
	}
	public int addRating(RatingDTO rtd) {
		Statement stmt;
		int s = 0;
		String query = "insert into rating ( movie_id, Rating, user_id ) values ( "+ 
				rtd.getMovie_id()
				+ ", " + rtd.getRating() + ", "+rtd.getUser_id() + ")";
		String query2 = "update movie set Average_rating = (Select avg(Rating) from rating where movie_id = " + rtd.getMovie_id() + ")"
				+ "where movie_id = " + rtd.getMovie_id();
		
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(query);
			s = stmt.executeUpdate(query2);
		}
		catch(Exception e){
			
			
		}
		return s;
	}
	public List<MovieDTO> listMovieDTOForGenre(String gen){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie where Genre = "+ "'"+gen+"'");
			while (rs.next()) {
//				System.out.println(rs.getInt(1));
				emps.add(new MovieDTO(rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(1),  rs.getInt(7), rs.getDouble(6)));
			}

		} catch (Exception e) {}
		
		return emps;
	}
	public List<MovieDTO> listMovieDTOOverall(){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie order by Average_rating desc limit 10");
			while (rs.next()) {
//				System.out.println(rs.getInt(1));
				emps.add(new MovieDTO(rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(1),  rs.getInt(7), rs.getDouble(6)));
			}

		} catch (Exception e) {}
		
		return emps;
	}
	public List<MovieDTO> listMovieDTOByGenre(String st){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie where Genre = " + "'" + st + "'"+  "order by Average_rating desc limit 10");
			while (rs.next()) {
//				System.out.println(rs.getInt(1));
				emps.add(new MovieDTO(rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(1),  rs.getInt(7), rs.getDouble(6)));
			}

		} catch (Exception e) {}
		
		return emps;
	}
	public List<MovieDTO> listMovieDTOName(String st){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie where movie_name = " + "'" + st + "'");
			while (rs.next()) {
//				System.out.println(rs.getInt(1));
				emps.add(new MovieDTO(rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(1),  rs.getInt(7), rs.getDouble(6)));
			}

		} catch (Exception e) {}
		
		return emps;
	}
	public List<MovieDTO> listMovieDTOGenre(String st){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie where Genre = " + "'" + st + "'");
			while (rs.next()) {
//				System.out.println(rs.getInt(1));
				emps.add(new MovieDTO(rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(1),  rs.getInt(7), rs.getDouble(6)));
			}

		} catch (Exception e) {}
		
		return emps;
	}
	public String utilForMovie(int choice, int mvid) throws SQLException {
		Statement stmt = con.createStatement();
		
		if(choice==1) {
			String query = "Select Summary from movie where movie_id = "+ mvid;
			ResultSet rs = stmt.executeQuery(query);
			String ans = "";
			while(rs.next()) {
				ans = rs.getString(1);
				break;
			}
			return ans;
			
			
		}
		else if(choice==2) {
			String query = "Select cast from movie where movie_id = "+ mvid;
			ResultSet rs = stmt.executeQuery(query);
			String ans = "";
			while(rs.next()) {
				ans = rs.getString(1);
				break;
			}
			return ans;
			
		}
		else {
			String query = "Select Genre from movie where movie_id = "+ mvid;
			ResultSet rs = stmt.executeQuery(query);
			String ans = "";
			while(rs.next()) {
				ans = rs.getString(1);
				break;
			}
			return ans;
			
		}
	}
	public List<ReviewDTO> utilForMovieForReview(int mvid) throws SQLException {
		Statement stmt = con.createStatement();
		
		
			String query = "Select * from review where movie_id = "+ mvid;
			ResultSet rs = stmt.executeQuery(query);
			List<ReviewDTO> lst =  new ArrayList<>();
			while(rs.next()) {
				lst.add(new ReviewDTO(rs.getInt(1), rs.getInt(2), rs.getInt(4), rs.getString(3)));
			}
			return lst;
		
		
		
	}
	

	public List<MovieDTO> listMovieDTO(){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie");
			while (rs.next()) {
				System.out.println(rs.getInt(1));
			}
		} catch (Exception e) {}
		
		return emps;
	}
	public List<MovieDTO> listMovieByOverall(){
		List<MovieDTO> emps=new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from movie order by Average_rating desc");
			while (rs.next()) {
				System.out.println(rs.getInt(1));
			}
		} catch (Exception e) {}
		
		return emps;
	}
	public void finalise(){
		try {
			con.close();
		} catch (SQLException e) {}
	}
	
	

}
