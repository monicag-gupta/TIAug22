package dtoForPrj;

public class ReviewDTO {
	int review_id, movie_id, user_id;
	String review;
	public int getReview_id() {
		return review_id;
	}
	public void setReview_id(int review_id) {
		this.review_id = review_id;
	}
	public ReviewDTO() {	
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Review details are [review_id=" + review_id + ", movie_id=" + movie_id + ", user_id=" + user_id + ", review="
				+ review + "]";
	}
	public int getMovie_id() {
		return movie_id;
	}
	public ReviewDTO(int review_id, int movie_id, int user_id, String review) {
		super();
		this.review_id = review_id;
		this.movie_id = movie_id;
		this.user_id = user_id;
		this.review = review;
	}
	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public String beautify(String s) {
		return "'"+s+"'";
	}
	
}
