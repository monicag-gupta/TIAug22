package dtoForPrj;

public class MovieDTO {
	String movie_name, summary, cast, genre, review;
	int movie_id, user_id;
	double Average_rating = 0.0;
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getCast() {
		return cast;
	}
	public void setCast(String cast) {
		this.cast = cast;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public int getMovie_id() {
		return movie_id;
	}
	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public MovieDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Movie details are [movie_name=" + movie_name + ", summary=" + summary + ", cast=" + cast + ", genre=" + genre
				+ ", review=" + review + ", movie_id=" + movie_id + ", user_id=" + user_id
				+ ", Average_rating=" + Average_rating + "]";
	}
	public MovieDTO(String movie_name, String summary, String cast, String genre, 
			int movie_id, int user_id, double average_rating) {
		super();
		this.movie_name = movie_name;
		this.summary = summary;
		this.cast = cast;
		this.genre = genre;
		this.movie_id = movie_id;
		this.user_id = user_id;
		Average_rating = average_rating;
	}
	public double getAverage_rating() {
		return Average_rating;
	}
	public void setAverage_rating(double average_rating) {
		Average_rating = average_rating;
	}
	public String beautify(String s) {
		return "'"+s+"'";
	}
	
	
	

}
