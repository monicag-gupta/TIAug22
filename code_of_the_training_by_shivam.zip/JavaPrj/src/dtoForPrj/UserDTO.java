package dtoForPrj;

public class UserDTO {
	int ID;
	String Name, EmailID;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	@Override
	public String toString() {
		return "User details are [ID=" + ID + ", Name=" + Name + ", EmailID=" + EmailID + "]";
	}
	public String getName() {
		return Name;
	}
	public UserDTO(int iD, String name, String emailID) {
		super();
		ID = iD;
		Name = name;
		EmailID = emailID;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmailID() {
		return EmailID;
	}
	public void setEmailID(String emailID) {
		EmailID = emailID;
	}
	public String beautify(String s) {
		return "'"+s+"'";
	}
	
	

}
