package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;
import java.util.*;
import daos.DAOForMovie;
import dtoForPrj.MovieDTO;
import dtoForPrj.RatingDTO;
import dtoForPrj.ReviewDTO;

public class Main {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		DAOForMovie daomovie = new DAOForMovie();
		while(true) {
			System.out.println("Please find below the applicable choices: ");
			System.out.println("Following features are available for only registered users and you will be asked to give your user id.");
			System.out.println("Enter 1 for adding a movie.");
			System.out.println("Enter 2 for editing a current movie entry.");
			System.out.println("Enter 3 for adding a review for a movie.");
			System.out.println("Enter 4 for adding a rating for a movie.");
			System.out.println("Following features are available publicly.");
			System.out.println("Enter 5 to view all the movies from a particular genre.");
			System.out.println("Enter 6 to view the top 10 movies overall.");
			System.out.println("Enter 7 to view the top 10 moview from a particulare genre.");
			System.out.println("Enter 8 to search for a particular movie by name.");
			System.out.println("Enter 9 to search movie by genre.");
			System.out.println("Enter 10 to view particular details of a movie such as summary, cast, genre, reviews.");
			System.out.println("Enter -1 to quit.");
			// as soon as a new a rating is added for a movie its average rating should also be updated by default it will be 0.0
			int choice = 0;
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();
			if(choice==-1) {
				daomovie.finalise();
				System.out.println("Bye.");
			}
			else if(choice<=4) {
				System.out.println("Please enter your user_id");
				int user_id = sc.nextInt();
				if(choice==1) {
					MovieDTO mvi = new MovieDTO();
					String content = sc.nextLine(); 
					System.out.println("Enter movie name.");
					content = sc.nextLine();
					mvi.setMovie_name(content);
					System.out.println("Enter movie summary.");
					content  = sc.nextLine();
					mvi.setSummary(content);
					System.out.println("Enter movie cast.");
					content  = sc.nextLine();
					mvi.setCast(content);
					System.out.println("Enter movie genre.");
					content = sc.nextLine();
					mvi.setGenre(content);
					mvi.setUser_id(user_id);
					daomovie.addMovie(mvi);
				}
				else if(choice==2) {
					MovieDTO mvi = new MovieDTO();
					String content = sc.nextLine(); 
					System.out.println("Enter movie name.");
					content = sc.nextLine();
					mvi.setMovie_name(content);
					System.out.println("Enter movie summary.");
					content  = sc.nextLine();
					mvi.setSummary(content);
					System.out.println("Enter movie cast.");
					content  = sc.nextLine();
					mvi.setCast(content);
					System.out.println("Enter movie genre.");
					content = sc.nextLine();
					mvi.setGenre(content);
					System.out.println("Enter movie id.");
					int id = sc.nextInt();
					mvi.setMovie_id(id);
					mvi.setUser_id(user_id);
					daomovie.updateMovie(mvi);
				}
				else if(choice==3)
				{
					ReviewDTO rvd = new ReviewDTO();
					String content = sc.nextLine();
					System.out.println("Enter review content.");
					content = sc.nextLine();
					rvd.setReview(content);
					System.out.println("Enter the movie id.");
					int mvid =  sc.nextInt();
					rvd.setUser_id(user_id);
					rvd.setMovie_id(mvid);
					daomovie.addReview(rvd);
				}
				else if(choice==4) {
					RatingDTO rtd = new RatingDTO();
					System.out.println("Enter movie id");
					int mvid = sc.nextInt();
					rtd.setMovie_id(mvid);
					System.out.println("Enter rating");
					int rating  = sc.nextInt();
					rtd.setRating(rating);
					rtd.setUser_id(user_id);
					daomovie.addRating(rtd);
					
				}
				
			}
			else if(choice>4&&choice<=10) {
				if(choice==5) {
					String genr = sc.nextLine();
					System.out.println("Enter Genre. ");
					genr = sc.nextLine();
					List <MovieDTO> lst = daomovie.listMovieDTOForGenre(genr);
					for(MovieDTO s: lst) {
						System.out.println(s);
					}	
				}
				else if(choice==6) {
					List <MovieDTO> lst = daomovie.listMovieDTOOverall();
					for(MovieDTO s: lst) {
						System.out.println(s);
					}	
				}
				else if(choice==7)
				{
					System.out.println("Please enter the genre for which you want top 10 movies.");
					String st = sc.next();
					List <MovieDTO> lst = daomovie.listMovieDTOByGenre(st);
					for(MovieDTO s: lst) {
						System.out.println(s);
					}	
				}
				else if(choice==8) {
					System.out.println("Enter the name of movie.");
					String st = sc.next();
					List <MovieDTO> lst = daomovie.listMovieDTOName(st);
					for(MovieDTO s: lst) {
						System.out.println(s);
					}	
				}
				else if(choice==9) {
					System.out.println("Enter the genre of the movie.");
					String st = sc.next();
					List <MovieDTO> lst = daomovie.listMovieDTOGenre(st);
					for(MovieDTO s: lst) {
						System.out.println(s);
					}	
				}
				else if(choice==10) {
					System.out.println("Enter movie id of the movie.");
					int mvid = sc.nextInt();
					System.out.println("Enter 1 for summary, 2 for cast, 3 for genre, and 4 for reviews.");
					int nwchoice = sc.nextInt();
					if(nwchoice<=3&&nwchoice>=1) {
						System.out.println(daomovie.utilForMovie(nwchoice, mvid));
					}
					else if(nwchoice==4) {
					  List<ReviewDTO> lst =  daomovie.utilForMovieForReview(mvid);
					  for(ReviewDTO rtd: lst) {
						  System.out.println(rtd);
					  }
					}
					else {
						System.out.println("Invalid Choice.");
					}
				}
				
			}
			else {
				System.out.println("Invalid Choice.");
			}
			
			
			
		}
		
		
		
	}

}
