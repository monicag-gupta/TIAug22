package concurrrentPkg;
import java.util.concurrent.*;  

class Wth implements Callable<String>{
	public String call(){
		return "Hello World";
	}
}
public class CallableEg {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		Future<String> f = executor.submit(new Wth());
		System.out.println(f.get());
	}

}