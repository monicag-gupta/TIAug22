package concurrrentPkg;
import java.util.concurrent.*;  


public class CallableWithLambda {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService executor = Executors.newSingleThreadExecutor();
		System.out.println(executor.submit(()->"Hello World of Java").get());
	}
}
