package threading;

import java.util.Scanner;

public class threadEx {
	public static void main(String[] args) {
		
		Runnable sum = ()->{
			Scanner sc = new Scanner(System.in);
				System.out.println("Enter two numbers for their sum");
				int a=5, b=4;
				a =  sc.nextInt();
				b =  sc.nextInt();
				System.out.println("The sum is "+(a+b));
		};
		Runnable product = ()->{
			Scanner sc = new Scanner(System.in);
				System.out.println("Enter two numbers for their product");
				int a=3, b=2;
				a =  sc.nextInt();
				b =  sc.nextInt();
				System.out.println("The product is "+(a*b));
		};
		
		Thread t1=  new Thread(sum);
		Thread t2 = new Thread(product);
		t1.start();
		t2.start();
	}

}
