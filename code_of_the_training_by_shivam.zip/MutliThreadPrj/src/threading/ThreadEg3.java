package threading;

class Thr implements Runnable{
//	String n;
//	Th(){n="MyTh";}
//	Th(String n){this.n=n;}
	public void run(){
		for(int i=0;i<10;i++){
			System.out.println(Thread.currentThread().getName() + " Iteration: " + i);
		}
	}
}

public class ThreadEg3 {

	public static void main(String[] args) {
		
//		Th th1=new Th("t1");
//		Th th2=new Th("t2");
		Thread t1=new Thread(new Thr());
		Thread t2=new Thread(new Thr());
		t1.start();
		t2.start();

	}

}
