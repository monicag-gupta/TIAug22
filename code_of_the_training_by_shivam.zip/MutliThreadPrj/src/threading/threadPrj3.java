package threading;
public class threadPrj3 extends Thread {
	public void run() {
		System.out.println("Start.. " + Thread.currentThread().getName());
		try {
			Thread.sleep(300);
		} catch (InterruptedException ie) {
		}
		System.out.println("End.. " + Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		threadPrj3 c1 = new threadPrj3();
		threadPrj3 c2 = new threadPrj3();
		System.out.println("Main Start.. ");
		c1.start();
		try {
			c1.join(); // Waiting for c1 to finish
		} catch (InterruptedException ie) {
		}
		c2.start();
		System.out.println("Main Ends.. ");
	}
}