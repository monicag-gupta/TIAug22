package threading;

class Th implements Runnable{
	String n;
	Th(){n="MyTh";}
	Th(String n){this.n=n;}
	public void run(){
		for(int i=0;i<10;i++){
			System.out.println("Thread: " + n + " Iteration: " + i);
		}
	}
}

public class ThreadEg1 {

	public static void main(String[] args) {
		
		Th th1=new Th("t1");
		Th th2=new Th("t2");
		Thread t1=new Thread(th1);
		Thread t2=new Thread(th2);
		t1.start();
		t2.start();

	}

}















//class Th extends Thread{
//	String n;
//	Th(){n="MyTh";}
//	Th(String n){this.n=n;}
//	public void run(){
//		for(int i=0;i<10;i++){
//			System.out.println("Thread: " + n + " Iteration: " + i);
//		}
//	}
//}
//
//public class ThreadEg1 {
//
//	public static void main(String[] args) {
//		Th t1=new Th("t1");
//		Th t2=new Th("t2");
//		t1.start();	
//		t2.start();
//
//	}
//
//}
