package threading;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Account { // the 'monitor'
	int balance;
	String name;

	public Account(int b, String n) {
		name = n;
		balance = b;
	}

	public Account() {
	}

	// if 'synchronized' is removed, the outcome is unpredictable
	public synchronized void deposit(int deposit_amount) {
		System.out.println("\nDeposit amount " + deposit_amount
				+ "in account: " + name);
		balance += deposit_amount;
	}

	public synchronized void withdraw(int deposit_amount) {
		System.out.println("\nWithdrawn amount" + deposit_amount
				+ "from account: " + name);
		balance -= deposit_amount;
	}

	public synchronized void enquire() {
		System.out.println("\nBalance for Account: " + name + " = " + balance);
	}
	public synchronized void createeAccount (List<Account> lst) {
		lst.add(this);
	}
}

class DepoThread implements Runnable {
	Account account;
	int amt;

	public DepoThread(Account s, int a) {
		account = s;
		amt = a;
	}

	public void run() {
		account.deposit(amt);
	}
}

class DrawThread implements Runnable {
	Account account;
	int amt;

	public DrawThread(Account s, int a) {
		account = s;
		amt = a;
	}

	public void run() {
		account.withdraw(amt);
	}
}

class BalThread implements Runnable {
	Account account;

	public BalThread(Account s) {
		account = s;
	}

	public void run() {
		account.enquire();
	}
	
}

class createAccountThread implements Runnable{
	Account account;
	List<Account> lst;
	public createAccountThread(List<Account> lst, String name, int amt) {
		this.lst = lst;
		account = new Account(amt, name);
	}
	public void run() {
		account.createeAccount(lst);
	}
}





public class synchronousEx {
	public static void main(String[] args) {
		int choice = 0;
		List<Account> col =  new ArrayList<Account>();
		while(true) {
			Scanner sc =  new Scanner(System.in);
			System.out.println("Enter 1 to create new account, 2 to withdraw, 3 to deposit, 4 for balance, -1 to quit.");
			choice = sc.nextInt();
			if(choice==-1) {
				break;
			}
			if(choice==1)
			{
				String name;
				int balance = 0;
				System.out.println("Enter your name and balance.");
				name = sc.next();
				balance =  sc.nextInt();
				Thread t1 =  new Thread(new createAccountThread(col, name, balance));
				t1.run();
			}
			else if(choice==2) {
				System.out.println("Enter your name and amount");
				int amt;
				String name;
				name = sc.next();
				amt =  sc.nextInt();
				Account aa =  new Account();
				for(Account a: col) {
					if(a.name.compareTo(name)==0) {
						aa = a;
						break;
					}
				}
				Thread t2 = new Thread(new DrawThread(aa, amt));
				t2.run();
			}
			else if(choice==3) {
				System.out.println("Enter your name and amount");
				int amt;
				String name;
				name = sc.next();
				amt =  sc.nextInt();
				Account aa =  new Account();
				for(Account a: col) {
					if(a.name.compareTo(name)==0) {
						aa = a;
						break;
					}
				}
				Thread t3 = new Thread(new DepoThread(aa, amt));
				t3.run();
			}
			else if(choice==4) {
				System.out.println("Enter your name.");
				String name;
				name = sc.next();
				Account aa = new Account();
				for(Account a: col) {
					if(a.name.compareTo(name)==0) {
						aa = a;
						break;
					}
				}
				Thread t4 = new Thread(new BalThread(aa));
				t4.run();
			}
			else {
				System.out.println("Invalid choice.");
			}
			
		}
	}
}


