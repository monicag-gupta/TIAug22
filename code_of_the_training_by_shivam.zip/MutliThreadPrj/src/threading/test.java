package threading;

import java.util.List;
import java.util.*;
class testt{
	public void tf(List<Integer> lst) {
		lst.add(24);
	}
	
}

public class test {
	public static void main(String[] args) {
		testt tt = new testt();
		List<Integer> lst = new ArrayList<>();
		lst.add(89);
		System.out.println(lst);
		tt.tf(lst);
		System.out.println(lst);
	}

}
