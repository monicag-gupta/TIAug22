package threading;
import java.util.Scanner;
//Design the previous chat application to get the values from the user as a scanner input. 
//Till at least one of them says “bye”
//System.exit();

class chatBox{
	boolean flag =false;
	// first the person1 will message..
	public synchronized void person1Msg() {
		if(flag) {
			try {
				wait();
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		Scanner sc =  new Scanner(System.in);
		System.out.print("Person 1, enter your message--> ");
		String message  = sc.nextLine();
		if(message.compareTo("bye")==0) {
			System.out.println("Exited.");
			System.exit(0);
		}
		System.out.println("Person1: "+message);
		flag = true;
		notify();
	}
	public synchronized void person2Msg() {
		if(!flag) {
			try {
				wait();
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		Scanner sc =  new Scanner(System.in);
		System.out.print("Person 2, enter your message--> ");
		String message  = sc.nextLine();
		if(message.compareTo("bye")==0) {
			System.out.println("Exited.");
			System.exit(0);
		}
		System.out.println("Person2: "+message);
		flag = false;
		notify();
	}
}

class Person1 implements Runnable{
	chatBox c;
	public Person1(chatBox c){
		this.c = c;
		new Thread(this).start();
		
	}
	public void run() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			c.person1Msg();
			
		}
	}
}

class Person2 implements Runnable{
	chatBox c;
	public Person2(chatBox c){
		this.c = c;
		new Thread(this).start();
		
	}
	public void run() {
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			c.person2Msg();
		}
	}
	
}

public class testThreadEx {
	public static void main(String[] args) {
		chatBox c =  new chatBox();
		new Person1(c);
		new Person2(c);
	}
}
