package rng_game;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;
import java.util.*;
public class rngGameMain {
	public static void main(String[] args) throws FileNotFoundException {
		String path = "/Users/Shivam/shivam_tr/wordlist.txt";
		File lst = new File(path);
		Scanner sc = new Scanner(lst);
		int cnt = 0, sz = 42;
		String[] stringList = new String[sz]; 
		while(sc.hasNextLine()) {
			stringList[cnt] = sc.nextLine();
			cnt++;
		}
		sc =  new Scanner(System.in);
		int max = 41, min = 0;
		int ind = (int)(Math.random()*(max-min+1)+min);
		String ans = stringList[ind];
		char underscore = '_';
		StringBuffer current  = new StringBuffer();
		for(int i=0;i<ans.length();i++) {
			current.append(underscore);
			if(i!=ans.length()-1) {
				current.append(" ");
			}
		}
		int currattempts =8;
		
		System.out.println("Welcome to Hangman.");
		System.out.println("You are having 8 attempts to either ask for an alphabet or guessing the word directly.\n"
				+ "You can guess the word only once, whereas you are having eight attempts to guess the alphabet,\n"
				+ "which can be possibly found in the word. "
				+ "After your each guess, the status of the word will be changed.\n"
						+ "You will get penalty only when you guess wrongly.");
		
		int cntinue = 1;
		int[] used =  new int[130];
		int[] present =  new int[130];
		for(int i = 0;i<ans.length();i++) {
			present[ans.charAt(i) - 'a'] = 1;
		}
		
		while(currattempts!=0&&cntinue==1) {
				
			System.out.println("Hello User, The current status of the word is written below !");
			System.out.println(current);
			System.out.println("Enter 0 for guessing the word directly, 1 for asking the alphabet. Currently there are "+
			currattempts+" attempts remaining.");
			int choice =0;
			int flag = 0;
			choice = sc.nextInt();
			if(choice==0) {
				System.out.println("Please enter the name of the word guessed by you.");
				String userAns   = sc.next();
				if(userAns.compareTo(ans)==0) {
					System.out.println("Congratulations!! You guessed the word correctly.");
				}
				else{
					System.out.println("You lost the game. Better luck next time. The correct answer is "+ans);
				}
				break;
			}
			else {
				System.out.println("Please enter the character which you want to ask.");
				char ch;
				ch = sc.next().charAt(0);
				if(used[ch -'a']==0) {
					used[ch - 'a']=1;
					if(present[ch - 'a']==1) {
						flag =1;
						for(int i=0;i<ans.length();i++) {
							if(ans.charAt(i)==ch) {
									current.setCharAt(2*i, ch);
							}
						}
						StringBuffer cmpst = new StringBuffer();
						for(int i=0;i<current.length();i++) {
							if(current.charAt(i)!=' ') {
								cmpst.append(current.charAt(i));
							}
						}
						if(cmpst.toString().compareTo(ans)==0) {
							System.out.println("Congratulations!! You guessed the word correctly.");
							break;
						}
					}
					
				}
				else {
					System.out.println("This character is already used.");
					flag = 1;
				}
			}
			if(flag==0)
			currattempts--;
			if(currattempts==0) {
				System.out.println("You have used all of your attempts. Now you will have to guess the word. Enter the word.");
				String finalans = sc.next();
				if(finalans.compareTo(ans)==0) {
					System.out.println("Congratulations!! You guessed the word correctly.");
				}
				else
				System.out.println("You lost the game. Better luck next time. The correct answer is "+ans);
			}
			
		}
		
	}
	

}
