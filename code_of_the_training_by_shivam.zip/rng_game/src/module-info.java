module rng_game {
}