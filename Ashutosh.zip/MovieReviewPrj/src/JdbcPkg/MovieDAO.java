package JdbcPkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.Movie;

public class MovieDAO {
	Connection con;

	public MovieDAO() {
		con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb", "root", "password");
			// here javadb is database name, root is username and password
		} catch (Exception e) {
		}
	}

	public int save(Movie e) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("insert into Movies(`title`,`summary`,`cast`,`genres`,`userId`) values('"
					+ e.getTitle() + "','" + e.getSummary() + "', '" + e.getCast() + "','" + e.getGenres() + "',"
					+ e.getUserId() + ")");
		} catch (SQLException e1) {
		}
		return s;
	}

	public int update(String title, String summary) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("Update Movies set summary ='" + summary + "' where  title='" + title + "'");
		} catch (SQLException e1) {
		}
		return s;
	}

	public List<Movie> listMovie() {
		List<Movie> movies = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Movies");
			while (rs.next())
				movies.add(new Movie(rs.getString(2), rs.getString(3), rs.getString(5), rs.getString(4), rs.getInt(6)));
		} catch (Exception e) {
		}

		return movies;
	}

	public int find(String title) {
		int x = 0;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select id from Movies where title='" + title + "'");
			while (rs.next())
				x = rs.getInt(1);
		} catch (Exception e) {
		}
		return x;
	}

	public void detail(int id) {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Movies where id=" + id);
			while (rs.next())
				System.out.println(
						new Movie(rs.getString(2), rs.getString(3), rs.getString(5), rs.getString(4), rs.getInt(6)));
			ResultSet rs1 = stmt.executeQuery("select * from ReviewAndRating where movieId=" + id);
			while (rs1.next())
				System.out.println("Review:" + rs1.getString(2) + " Rating:" + rs1.getInt(3));
		} catch (Exception e) {
		}
	}

	public void finalise() {
		try {
			con.close();
		} catch (SQLException e) {
		}
	}

}
