package JdbcPkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entities.User;

public class UserDAO {
	Connection con;

	public UserDAO() {
		con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb", "root", "password");
			// here javadb is database name, root is username and password
		} catch (Exception e) {
		}
	}

	public int save(User e) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate(
					"insert into Users(`name`,`emailId`) values('" + e.getName() + "', '" + e.getEmailId() + "')");
		} catch (SQLException e1) {
		}
		return s;
	}

	public int find(String email) {
		int x = 0;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select id from Users where emailId='" + email + "' ");
			while (rs.next())
				x = (rs.getInt(1));
		} catch (Exception e) {
		}
		return x;
	}

	public void finalise() {
		try {
			con.close();
		} catch (SQLException e) {
		}
	}

}
