package JdbcPkg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.ReviewAndRating;

public class ReviewAndRatingDAO {
	Connection con;

	public ReviewAndRatingDAO() {
		con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javadb", "root", "password");
			// here javadb is database name, root is username and password
		} catch (Exception e) {
		}
	}

	public int save(ReviewAndRating e) {
		Statement stmt;
		int s = 0;
		try {
			stmt = con.createStatement();
			s = stmt.executeUpdate("insert into ReviewAndRating(`review`,`rating`,`movieId`,`userId`) values('"
					+ e.getReview() + "','" + e.getRating() + "', " + e.getMovieId() + "," + e.getUserId() + ")");
		} catch (SQLException e1) {
		}
		return s;
	}

	public List<String> find(int movieId) {
		List<String> l = new ArrayList<String>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select review from ReviewAndRating where movieId=" + movieId);
			while (rs.next())
				l.add(rs.getString(1));
		} catch (Exception e) {
		}
		return l;
	}

	public void top10() {
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"select title,avg(rating) as Rating from movies right join reviewandrating on movies.id=movieId group by movieId order by Rating desc limit 10");
			while (rs.next())
				System.out.println(rs.getString(1) + " " + rs.getDouble(2));
		} catch (Exception e) {
		}
	}

	public void finalise() {
		try {
			con.close();
		} catch (SQLException e) {
		}
	}

}
