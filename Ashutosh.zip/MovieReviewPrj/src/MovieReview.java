import java.util.Scanner;

import JdbcPkg.MovieDAO;
import JdbcPkg.ReviewAndRatingDAO;
import JdbcPkg.UserDAO;
import entities.Movie;
import entities.ReviewAndRating;
import entities.User;

//Create table movies (id INT Auto_increment NOT NULL Primary Key, title varchar(100) Not Null,summary varchar(500),cast  varchar(200),genres varchar(200),userId int, FOREIGN KEY (userId) REFERENCES users(id) );
//Create table ReviewAngRating (id INT Auto_increment NOT NULL Primary Key,review varchar(200),Rating int , movieaiad int not Null,userId int, FOREIGN KEY (userId) REFERENCES users(id))
//Create table users(id int Auto_increment NOT NULL Primary Key, name varchar(100) Not Null,emailId varchar(100) Not Null Unique )

public class MovieReview {

	public static void main(String[] args) {
		System.out.println("Hii");
		UserDAO userdao = new UserDAO();
		MovieDAO moviedao = new MovieDAO();
		ReviewAndRatingDAO rdao = new ReviewAndRatingDAO();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Press 1 to add new user");
			System.out.println("Press 2 to add new movie");
			System.out.println("Press 3 to add new review or rate a movie");
			System.out.println("Press 4 to print movies");
			System.out.println("Press 5 to update summary details oof movie");
			System.out.println("Press 6 to view reviews for a movie");
			System.out.println("Press 7 to see all details of a movie");
			System.out.println("Press 8 to view top 10 movies based on rating");
			System.out.println("Press 9 to exit");
			int x = sc.nextInt();
			if (x == 1) {
				System.out.println("Enter your name:");
				String name = sc.next();
				System.out.println("Enter your email:");
				String email = sc.next();
				int save = userdao.save(new User(name, email));
				if (save == 1)
					System.out.println("Success");
				else
					System.out.println("Email id already exists");
			} else if (x == 2) {
				System.out.println("Enter your registered email:");
				String email = sc.next();
				int id = userdao.find(email);
				if (id != 0) {
					System.out.println("Enter movie title:");
					String title = sc.next();
					System.out.println(("Enter summary:"));
					String summary = sc.nextLine();
					summary = sc.nextLine();
					System.out.println("Enter genres:");
					String genres = sc.next();
					System.out.println("Enter lead cast:");
					String cast = sc.next();
					int save = moviedao.save(new Movie(title, summary, genres, cast, id));
					if (save == 1)
						System.out.println("Success!!");
					else
						System.out.println("Something went wrong, Please try again");
				} else
					System.out.println("Email id doesn't exist. Please try again!");
			}
			if (x == 3) {
				System.out.println("Enter your email:");
				String email = sc.next();
				int userid = userdao.find(email);
				if (userid == 0) {
					System.out.println("Please register and come again?");
					continue;
				}
				System.out.println("Enter title of movie:");
				String title = sc.next();
				int movieid = moviedao.find(title);
				if (movieid == 0) {
					System.out.println("Sorry movie does not exists.");
					continue;
				}
				System.out.println("Please give ur valuable reviews.");
				String review = sc.nextLine();
				review = sc.nextLine();
				System.out.println("Please rate our movie in the scale of 1-5 :");
				int rating = sc.nextInt();
				int save = rdao.save(new ReviewAndRating(review, rating, movieid, userid));
				if (save == 1)
					System.out.println("Success!");
				else
					System.out.println("Something went wrong Please try again!");
			} else if (x == 4) {
				System.out.println(moviedao.listMovie());
			} else if (x == 5) {
				System.out.println("Enter your registered email:");
				String email = sc.next();
				int id = userdao.find(email);
				if (id == 0) {
					System.out.println("Not a valid user!");
					continue;
				}
				System.out.println("Enter title of movie:");
				String title = sc.next();
				int movieid = moviedao.find(title);
				if (movieid == 0) {
					System.out.println("Movie does not exist");
					continue;
				}
				System.out.println("Enter summary of movie:");
				String summary = sc.nextLine();
				summary = sc.nextLine();
				int update = moviedao.update(title, summary);
				if (update == 1)
					System.out.println("Success");
				else
					System.out.println("omething went wroong!");
			} else if (x == 6) {
				System.out.println("Enter title of movie:");
				String title = sc.next();
				int id = moviedao.find(title);
				if (id == 0) {
					System.out.println("Movie does not exists");
					continue;
				}
				System.out.println(rdao.find(id));
			} else if (x == 7) {
				System.out.println("Enter title of movie:");
				String title = sc.next();
				int id = moviedao.find(title);
				if (id == 0) {
					System.out.println("Movie does not exist.");
					continue;
				}
				moviedao.detail(id);
			} else if (x == 8) {
				rdao.top10();
			} else if (x == 9) {
				break;
			} else
				System.out.println("Please enter correct choice.");
		}
		System.out.println("Thank You");
	}
}
