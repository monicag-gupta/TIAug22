package entities;

public class ReviewAndRating {
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	private String review;
	private int rating;
	private int movieId;
	private int userId;
	@Override
	public String toString() {
		return "ReviewAndRating [review=" + review + ", rating=" + rating + ", movieId=" + movieId + ", userId="
				+ userId + "]";
	}
	public ReviewAndRating(String review, int rating, int movieId, int userId) {
		super();
		this.review = review;
		this.rating = rating;
		this.movieId = movieId;
		this.userId = userId;
	}
	
	
}
