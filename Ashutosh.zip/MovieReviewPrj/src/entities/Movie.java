package entities;


public class Movie {
	int id;
	private String title,summary,genres,cast;
	int userId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getGenres() {
		return genres;
	}
	public void setGenres(String genres) {
		this.genres = genres;
	}
	public String getCast() {
		return cast;
	}
	public void setCast(String cast) {
		this.cast = cast;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Movie(String title, String summary, String genres, String cast, int userId) {
		super();
		this.title = title;
		this.summary = summary;
		this.genres = genres;
		this.cast = cast;
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", title=" + title + ", summary=" + summary + ", genres=" + genres + ", cast=" + cast
				+ ", userId=" + userId + "]";
	}
	
}
