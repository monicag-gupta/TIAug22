package Controller;

import com.mysql.cj.xdevapi.PreparableStatement;
import models.LoginModel;
import services.LoginService;
import java.sql.*;

public class LoginController implements LoginService {
    public boolean  registerUser(Connection connection, String email,  String name){
        try {
            PreparedStatement statement = connection.prepareStatement("insert into  users (user_name, email_id) values (?, ?);");
            statement.setString(1, name);
            statement.setString(2, email);
            return statement.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
        return true;
    }
    public LoginModel login(Connection connection, String email){
        LoginModel loginModel = new LoginModel();
        PreparedStatement statement = null;
        if(!email.trim().isEmpty()){
            try {
                statement = connection.prepareStatement("select user_id,user_name,email_id from users where email_id=?");
                statement.setString(1, email);
                ResultSet res =statement.executeQuery();
                res.next();
                loginModel.setUser_id(res.getInt(1));
                loginModel.setUsername(res.getString(2));
                loginModel.setEmail(res.getString(3));
                return loginModel;
            } catch (Exception e) {
                loginModel.setComment("No user present for given email");
                return loginModel;
            }
        }
        else{
            loginModel.setComment("enter valid email address");
            return loginModel;
        }
    }

}
