package Controller;

import models.MovieModel;
import models.RatingModel;
import models.ReviewModel;
import services.MovieService;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieController implements MovieService {
    public void insertMovie(Connection connection, MovieModel movieModel) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into movie (movie_name, Summary,cast, Genre, Average_rating, user_id) values (?,?,?,?,?,?)");
            preparedStatement.setString(1, movieModel.getMovie_name());
            preparedStatement.setString(2, movieModel.getSummary());
            preparedStatement.setString(3, movieModel.getCast());
            preparedStatement.setString(4, movieModel.getGenre());
            preparedStatement.setDouble(5, movieModel.getAverage_rating());
            preparedStatement.setInt(6, movieModel.getUser_id());
            preparedStatement.executeUpdate();
            System.out.println("Movie added Succesfully");
            MovieModel movieModel1 = searchMovie(connection,  movieModel.getMovie_name());
            RatingModel ratingModel = new RatingModel(movieModel1.getMovie_id(), movieModel.getAverage_rating(), Integer.parseInt(System.getProperty("UserID")));
            addRating(connection, ratingModel);
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Please try again");
        }
    }

    public void insertReview(Connection connection, ReviewModel reviewModel) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("insert into review ( movie_id, Review,  user_id) values (?,?,?)");
            preparedStatement.setInt(1, reviewModel.getMovie_id());
            preparedStatement.setString(2, reviewModel.getReview());
            preparedStatement.setInt(3, reviewModel.getUser_id());
            boolean response = preparedStatement.execute();
            System.out.println("review added successfully");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void addRating(Connection connection, RatingModel ratingModel) {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement("insert into ratings (movie_id, Rating,  user_id) values (?,?,?)");
            preparedStatement.setInt(1, ratingModel.getMovie_id());
            preparedStatement.setDouble(2, ratingModel.getRating());
            preparedStatement.setInt(3, ratingModel.getUser_id());
            boolean response = preparedStatement.execute();
            //whenever we add rating of movie, we have  to calculate avg rating in  movie;
            PreparedStatement preparedStatement1 = null;
            preparedStatement1 = connection.prepareStatement("update movie set Average_rating=( select avg(rating) from ratings where movie_id = ?)");
            preparedStatement1.setInt(1, ratingModel.getMovie_id());
            boolean response1 = preparedStatement1.execute();
            System.out.println("Rating added Successfully");


        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public MovieModel findById(Connection connection, int id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, user_id from movie where movie_id = ?");
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            MovieModel movieModel = new MovieModel();
            if(resultSet.next()){
                movieModel.setMovie_id(id);
                movieModel.setMovie_name(resultSet.getString(1));
                movieModel.setSummary(resultSet.getString(2));
                movieModel.setCast(resultSet.getString(3));
                movieModel.setGenre(resultSet.getString(4));
                movieModel.setAverage_rating(resultSet.getDouble(5));
                movieModel.setUser_id(resultSet.getInt(6));

                return movieModel;
            }
            else{
                return null;
            }
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }

    }

    public List<MovieModel> findByGenre(Connection connection, String genre, Boolean overall) {
        try {
            PreparedStatement preparedStatement;
            if (overall)
                preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, movie_id from movie where genre = ? order by average_rating desc limit 10");
            else
                preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, movie_id from movie where genre = ? ");

            preparedStatement.setString(1, genre);
            ResultSet resultSet = preparedStatement.executeQuery();
            List<MovieModel> movieList = new ArrayList<>();
            while (resultSet.next()) {
                MovieModel movieModel = new MovieModel();
                movieModel.setMovie_name(resultSet.getString(1));
                movieModel.setSummary(resultSet.getString(2));
                movieModel.setCast(resultSet.getString(3));
                movieModel.setGenre(resultSet.getString(4));
                movieModel.setAverage_rating(resultSet.getDouble(5));
                movieModel.setMovie_id(resultSet.getInt(6));
                movieList.add(movieModel);
            }
            if (movieList.isEmpty())
                System.out.println("No Movies available for given genre :(");
            return movieList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public List<MovieModel> findMovies(Connection connection, Boolean overall) {
        try {
            PreparedStatement preparedStatement;
            if (overall)
                preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, movie_id from movie order by average_rating desc limit 10");
            else
                preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, movie_id from movie ");

            ResultSet resultSet = preparedStatement.executeQuery();
            List<MovieModel> movieList = new ArrayList<>();
            while (resultSet.next()) {
                MovieModel movieModel = new MovieModel();
                movieModel.setMovie_name(resultSet.getString(1));
                movieModel.setSummary(resultSet.getString(2));
                movieModel.setCast(resultSet.getString(3));
                movieModel.setGenre(resultSet.getString(4));
                movieModel.setAverage_rating(resultSet.getDouble(5));
                movieModel.setMovie_id(resultSet.getInt(6));
                movieList.add(movieModel);
            }
            if (movieList.isEmpty())
                System.out.println("No Movies available for given genre :(");
            return movieList;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public MovieModel searchMovie(Connection connection, String movieName) {

        try {
            PreparedStatement preparedStatement = connection.prepareStatement("select movie_name, Summary,cast, Genre, Average_rating, movie_id from movie where movie_name = ?");
            preparedStatement.setString(1, movieName);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {

                MovieModel movieModel = new MovieModel();
                movieModel.setMovie_name(resultSet.getString(1));
                movieModel.setSummary(resultSet.getString(2));
                movieModel.setCast(resultSet.getString(3));
                movieModel.setGenre(resultSet.getString(4));
                movieModel.setAverage_rating(resultSet.getDouble(5));
                movieModel.setMovie_id(resultSet.getInt(6));

                movieModel.setStatusCode(200);

                return movieModel;
            } else {
                MovieModel movieModel = new MovieModel();
                movieModel.setStatusCode(404);
                System.out.println("No Movie available for the given name :(");
                return null;

            }


        } catch (Exception e) {
            System.out.println(e);
        }
        return  null;
    }
    public List<ReviewModel> findReviews(Connection connection, int movieId){
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement("select Review from review where movie_id = ?");
            preparedStatement.setInt(1, movieId);
            List<ReviewModel> reviewModelList = new ArrayList<>();
            ResultSet resultSet = preparedStatement.executeQuery();
            while(resultSet.next()){
                ReviewModel  reviewModel = new ReviewModel();
                reviewModel.setReview(resultSet.getString(1));
                reviewModelList.add(reviewModel);
            }
            return reviewModelList;

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    public void updateMovie(Connection connection, MovieModel movieModel){
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement("update movie set movie_name = ?, summary = ?, cast=?, genre=?, user_id=? where movie_id = ?");
            preparedStatement.setString(1, movieModel.getMovie_name());
            preparedStatement.setString(2, movieModel.getSummary());
            preparedStatement.setString(3, movieModel.getCast());
            preparedStatement.setString(4, movieModel.getGenre());
            preparedStatement.setInt(5, movieModel.getUser_id());
            preparedStatement.setInt(6, movieModel.getMovie_id());
            int response = preparedStatement.executeUpdate();
            if(response>=1)
            {
                System.out.println("Movie edited successfully");
            }
            else{
                System.out.println("Please try again");
            }
        }catch (Exception exception){
            System.out.println(exception);
        }
    }




}
