package models;

public class MovieModel {
    @Override
    public String toString() {
        return "MovieModel{" +
                "movie_id=" + movie_id +
                ", movie_name='" + movie_name + '\'' +
                ", Summary='" + Summary + '\'' +
                ", cast='" + cast + '\'' +
                ", Genre='" + Genre + '\'' +
                ", Average_rating=" + Average_rating +
                ", user_id=" + user_id +
                '}';
    }

    public MovieModel() {

    }

    public int getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public String getMovie_name() {
        return movie_name;
    }

    public void setMovie_name(String movie_name) {
        this.movie_name = movie_name;
    }

    public String getSummary() {
        return Summary;
    }

    public void setSummary(String summary) {
        Summary = summary;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    public double getAverage_rating() {
        return Average_rating;
    }

    public MovieModel(String movie_name, String summary, String cast, String genre, double average_rating, int user_id) {
        this.movie_name = movie_name;
        Summary = summary;
        this.cast = cast;
        Genre = genre;
        Average_rating = average_rating;
        this.user_id = user_id;
    }

    public void setAverage_rating(double average_rating) {
        Average_rating = average_rating;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    private int movie_id;
    private String movie_name ;
    private String Summary ;
    private String cast ;
    private String  Genre ;
    private double Average_rating ;
    private int user_id ;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String comment) {
        Comment = comment;
    }

    private int statusCode;
    private String statusMessage;
    private String Comment;


}
