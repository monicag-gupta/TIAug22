package models;

public class RatingModel {
    public RatingModel(int movie_id,Double rating, int user_id) {
        this.movie_id = movie_id;
        this.rating = rating;
        this.user_id = user_id;
    }

    public RatingModel() {

    }

    public int getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getRating_id() {
        return rating_id;
    }

    public void setRating_id(int rating_id) {
        this.rating_id = rating_id;
    }

    int movie_id;
    Double rating;
    int user_id;
    int rating_id;
}
