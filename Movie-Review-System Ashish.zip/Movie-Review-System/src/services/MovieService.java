package services;

import models.MovieModel;
import models.RatingModel;
import models.ReviewModel;

import java.sql.Connection;
import java.util.List;

public interface MovieService {
    public void insertMovie(Connection connection, MovieModel movieModel);
    public void addRating(Connection connection, RatingModel ratingModel);
    public void insertReview(Connection connection, ReviewModel reviewModel);
    public MovieModel searchMovie(Connection connection, String movieName);
    public List<MovieModel> findByGenre(Connection connection, String genre, Boolean overall);
    public List<ReviewModel> findReviews(Connection connection, int movieId);

    public List<MovieModel> findMovies(Connection connection, Boolean overall) ;
    public void updateMovie(Connection connection, MovieModel movieModel);
}
