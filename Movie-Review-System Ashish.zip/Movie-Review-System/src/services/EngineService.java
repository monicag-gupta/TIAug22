package services;

import java.sql.Connection;

public interface EngineService {
    public Connection run();
}
