package services;

import models.LoginModel;

import java.sql.Connection;

public interface LoginService {
    public boolean  registerUser(Connection connection, String email,  String name);
    public LoginModel login(Connection connection, String email);
}
