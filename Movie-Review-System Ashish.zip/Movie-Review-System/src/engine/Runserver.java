package engine;

import Controller.LoginController;
import Controller.MovieController;
import Logic.GeneralFlow;
import Logic.LoginFlow;
import com.mysql.cj.log.Log;
import models.LoginModel;
import models.MovieModel;
import models.RatingModel;
import models.ReviewModel;
import services.EngineService;
import services.LoginService;

import java.sql.Connection;
import java.lang.*;
import java.util.Properties;
import java.util.Scanner;

public class Runserver {
    public static void main(String[] args) {
        EngineService server = new DbServer();
        Connection connection = server.run();
        Properties props = new Properties();
        GeneralFlow generalFlow = new GeneralFlow(connection);
        System.setProperty("isLogged", "false");
        MovieController movieController = new MovieController();
        System.out.println("Welcome to Movie Review system :)");

        Scanner scanner = new Scanner(System.in);
        while(true){
            int i;
            System.out.println("Enter index from the below options");
            System.out.println("1. Login");
            System.out.println("2. Sign Up");
            System.out.println("3. Search Movie");
            System.out.println("4. Search by Genre");
            System.out.println("5. See top 10 movies");
            System.out.println("6. Watch top 10 movies of your genre");
            System.out.println("And any other key to end program");

            i = scanner.nextInt();
            if (i == 1) {

                System.out.println("Enter your email:");
                String email = scanner.next();
                LoginService loginService = new LoginController();
                LoginModel user = loginService.login(connection, email);
                if(user.getComment() == null){
                    System.setProperty("Username", user.getUsername());
                    System.setProperty("UserID", String.valueOf(user.getUser_id()));
                    System.setProperty("isLogged", "true");
                    System.out.println("Welcome " + user.getUsername());
                    new LoginFlow().loginOptions(connection);
                }
                else {
                    System.out.println("Please choose valid options");
                }

            } else if (i == 2) {
                System.out.println("Enter your name:");
                String name = scanner.next();
                System.out.println("Enter your email:");
                String email = scanner.next();
                LoginService loginService = new LoginController();
                if(!loginService.registerUser(connection, email,name)){
                    System.out.println("User Registered Successfully");
                }
                else{
                    System.out.println("Please choose valid option and fill details again");
                }


            } else if (i == 3) {
                generalFlow.searchByMovie();
            } else if (i == 4) {
                generalFlow.searchByGenre();
            } else if (i == 5) {
                generalFlow.topTenMovies();
            } else if(i == 6) {
                generalFlow.topTenGenreMovies();

            }
            else{
                System.out.println("Thank you for visiting :)");
                break;
            }


        }


    }

}
