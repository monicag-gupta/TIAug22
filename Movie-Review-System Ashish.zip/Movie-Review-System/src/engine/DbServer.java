package engine;

import services.EngineService;

import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

class DbServer implements EngineService {
    private Connection connection;
    private Properties  properties;

    private void loadProperties(Path path) {
        try {
            FileReader fileReader = new FileReader(String.valueOf(path));
            this.properties = new Properties();
            this.properties.load(fileReader);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }


    public Connection run() {
        loadProperties(Paths.get("/Users/Ashish.Singh/Movie-Review-System/src/db.properties"));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:"+properties.getProperty("databasePort")+"/" + properties.getProperty("databaseName"), properties.getProperty("user"), properties.getProperty("password"));
            return connection;

        } catch (Exception E) {
            System.out.println("Exception occurred " + E);
        }
        return null;
    }

}
