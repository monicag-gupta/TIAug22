package Logic;

import Controller.MovieController;
import models.MovieModel;
import models.RatingModel;
import models.ReviewModel;
import services.MovieService;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class LoginFlow {

    private Scanner scanner  = new Scanner(System.in);
    private MovieService movieService = new MovieController();
    private GeneralFlow generalFlow;
    private Connection connection;


    public void loginOptions(Connection connection) {
        int value;
        this.connection  = connection;
        generalFlow = new GeneralFlow(connection);

        while(System.getProperty("isLogged") == "true"){
            System.out.println("Enter the index of query you want");
            System.out.println("1. Add Movie");
            System.out.println("2. Add Review to a movie");
            System.out.println("3. Rate a movie");
            System.out.println("4. Edit a movie");
            System.out.println("5. Search Movie");
            System.out.println("6. Search by Genre");
            System.out.println("7. See top 10 movies");
            System.out.println("8. Watch top 10 movies of your genre");
            System.out.println("9. Sign Out");
            value = scanner.nextInt();
            if( value == 1){
                System.out.println("Enter movie name:");
                MovieModel movieModel = new MovieModel() ;
                movieModel.setMovie_name(scanner.next());
                movieModel.setUser_id(Integer.parseInt(System.getProperty("UserID")));
                System.out.println("Enter genre:");
                movieModel.setGenre(scanner.next());
                System.out.println("Enter cast (Comma separated): ");
                movieModel.setCast(scanner.next());
                System.out.println("Enter summary of the movie");
                movieModel.setSummary(scanner.next());
                System.out.println("Enter rating");
                Double rating = scanner.nextDouble();
                movieModel.setAverage_rating(rating);
                movieService.insertMovie(connection, movieModel);
            }
            else if (value == 2){
                System.out.println("Enter movie name");
                String movieName  = scanner.next();
                MovieModel movieModel = movieService.searchMovie(connection, movieName);
                if(movieModel!=null){
                    System.out.println("Enter movie review");
                    ReviewModel reviewModel = new ReviewModel(Integer.parseInt(System.getProperty("UserID")), scanner.next(), movieModel.getMovie_id() );
                    movieService.insertReview(connection, reviewModel);
                }

            }
            else if( value == 3){
                System.out.println("Enter movie name");
                String movieName  = scanner.next();
                MovieModel movieModel = movieService.searchMovie(connection, movieName);
                if(movieModel!=null){

                    System.out.println("Enter the rating: ");
                    Double rating = scanner.nextDouble();
                    movieService.addRating(connection, new RatingModel(movieModel.getMovie_id(), rating, Integer.parseInt(System.getProperty("UserID"))));
                }

            } else if (value == 4) {
                System.out.println("Enter movie name");
                String movieName  = scanner.next();
                MovieModel movieModel = movieService.searchMovie(connection, movieName);
                if(movieModel!=null){
                    System.out.println("Enter updated movie name");
                    String var = scanner.next();
                    movieModel.setMovie_name(var.trim().isEmpty() ? movieModel.getMovie_name() : var);
                    System.out.println("Enter Summary");
                    String var1 = scanner.next();
                    movieModel.setSummary(var.trim().isEmpty() ? movieModel.getSummary() : var1);
                    System.out.println("Enter cast");
                    String var2 = scanner.next();
                    movieModel.setCast(var.trim().isEmpty() ? movieModel.getCast() : var2);
                    System.out.println("Enter genre");
                    String var3 = scanner.next();
                    movieModel.setGenre(var.trim().isEmpty() ? movieModel.getGenre() : var3);
                    movieModel.setUser_id(Integer.parseInt(System.getProperty("UserID")));
                    movieService.updateMovie(connection, movieModel);

                }




                } else if (value ==  5) {
                generalFlow.searchByMovie();
            } else if (value  == 6) {
                generalFlow.searchByGenre();

            } else if (value == 7) {
                generalFlow.topTenMovies();

            } else if ( value == 8) {
                generalFlow.topTenGenreMovies();
            }
            else {
                System.clearProperty("Username");
                System.clearProperty("UserID");
                System.setProperty("isLogged", "false");
                System.out.println("Logged Out");
                break;
            }


        }

    }

}
