package Logic;

import Controller.MovieController;
import models.MovieModel;
import models.ReviewModel;
import services.MovieService;

import javax.sound.midi.Soundbank;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GeneralFlow {
    public GeneralFlow(Connection connection) {
        this.connection = connection;
    }

    Scanner scanner = new Scanner(System.in);
    private MovieService movieService = new MovieController();
    private Connection connection;
    public void searchByGenre(){
        System.out.println("Enter genre: ");
        String genre = scanner.next();
        List<MovieModel> movieList = movieService.findByGenre(connection, genre, false);
        for(int i=0;i<movieList.size();i++){
            System.out.println(i + ". " + movieList.get(i).getMovie_name());
        }
        System.out.println("Enter index of movie you want details of: ");
        int  index = scanner.nextInt();
        showDetails(movieList.get(index));


    }
    public void searchByMovie(){
        System.out.println("Enter movie name");
        String movieName  = scanner.next();
        MovieModel movieModel = movieService.searchMovie(connection, movieName);
        if(movieModel != null)
        showDetails(movieModel);
    }
    public void topTenGenreMovies() {
        System.out.println("Enter genre: ");
        String genre = scanner.next();
        List<MovieModel> movieList = movieService.findByGenre(connection, genre, true);
        for (int i = 0; i < movieList.size(); i++) {
            System.out.println(i + " " + movieList.get(i).getMovie_name());
        }
        System.out.println("Enter index of movie you want details of: ");
        int index = scanner.nextInt();
        showDetails(movieList.get(index));
    }
    public void topTenMovies(){
        List<MovieModel> movieList = movieService.findMovies(connection, true);
        for(int i=0;i<movieList.size();i++){
            System.out.println(i + " " + movieList.get(i).getMovie_name());
        }
        System.out.println("Enter index of movie you want details of: ");
        int  index = scanner.nextInt();
        showDetails(movieList.get(index));

    }

    public void showDetails(MovieModel movieModel){
        System.out.println("Movie Name : " + movieModel.getMovie_name() + "\n"+
                            "Cast : " + movieModel.getCast() + "\n" +
                            "Summary : " + movieModel.getSummary() + "\n"+
                            "Genre : " + movieModel.getGenre() + "\n" +
                            "Rating : " + movieModel.getAverage_rating());
        List<ReviewModel> list = new ArrayList<>();
        list = movieService.findReviews(connection, movieModel.getMovie_id());
        String r = "";
        if(!list.isEmpty() && list!=null){
            for(int i=0;i<list.size();i++){
                r += list.get(i).getReview() + " ";
            }
            System.out.println("Reviews : " +  r);
        }


    }
}
